#ifndef __GATHRILLO__HARDWARECOMMUNICATION__GDT_H
#define __GATHRILLO__HARDWARECOMMUNICATION__GDT_H
#include <common/types.h>



namespace gathrillo
{


    class GlobalDescriptorTable {
        
     public:
         class SegmentDescriptor {
            
         private:
              gathrillo::common::uint16_t limit_lo;
              gathrillo::common::uint16_t base_lo;
              gathrillo::common::uint8_t base_hi;
              gathrillo::common::uint8_t type;
              gathrillo::common::uint8_t flags_limit_hi;
              gathrillo::common::uint8_t base_vhi;
             
         public:
           SegmentDescriptor(gathrillo::common::uint32_t base, gathrillo::common::uint32_t limit, gathrillo::common::uint8_t type);
            gathrillo::common::uint32_t Base();
            gathrillo::common::uint32_t Limit();
             
             
         }__attribute__((packed));
         
         SegmentDescriptor nullSegmentSelector;
         SegmentDescriptor unusedSegmentSelector;
         SegmentDescriptor codeSegmentSelector;
         SegmentDescriptor dataSegmentSelector;
         
    public:
        GlobalDescriptorTable();
        ~GlobalDescriptorTable();
        
         gathrillo::common::uint16_t CodeSegmentSelector();
         gathrillo::common::uint16_t DataSegmentSelector();

    };






}





















#endif