/*
#ifndef __GATHRILLO__UI__UII_H
#define __GATHRILLO__UI__UII_H

#include <gui/widget.h>
#include <drivers/mouse.h>
#include <drivers/game.h>
#include <gui/window.h>
#include <gui/desktop.h>
#include <drivers/vga.h>
#include <drivers/hopeidontfail.h>
namespace gathrillo
{

    namespace uii
    {
        class uii : public CompositeWidget, public gathrillo::drivers::MouseEventHandler
        {
        protected:
           // common::uint32_t angle;
            //common::uint32_t camera;
           // common::uint32_t MouseX;
           // common::uint32_t MouseY;
            
        public: 
           
           ui();
            ~ui();
           
        };
    }
}
    
*/
