#include <common/types.h>
#include <hardwarecommunication/pci.h>
#include <gui/desktop.h>
#include <gui/window.h>
#include <gui/widget.h>

#include <gui/3d_enviroment.h>


void printf(char* str);
void printfHex(gathrillo::common::uint8_t);


static inline gathrillo::common::uint8_t inb(gathrillo::common::uint16_t port)
{
    gathrillo::common::uint8_t ret;
    asm volatile ( "inb %1, %0"
                   : "=a"(ret)
                   : "Nd"(port) );
    return ret;
    
    
    
}

static inline void outb(gathrillo::common::uint16_t port, gathrillo::common::uint8_t val)
{
    asm volatile ( "outb %0, %1" : : "a"(val), "Nd"(port) );
    
    
}

static inline gathrillo::common::uint16_t inw(gathrillo::common::uint16_t port)
{
    gathrillo::common::uint16_t ret;
    asm volatile ( "inw %1, %0"
                   : "=a"(ret)
                   : "Nd"(port) );
    return ret;
    
    
    
}

static inline void outw(gathrillo::common::uint16_t port, gathrillo::common::uint16_t val)
{
    asm volatile ( "outw %0, %1" : : "a"(val), "Nd"(port) );
}

static inline gathrillo::common::uint32_t inl(gathrillo::common::uint16_t port)
{
    gathrillo::common::uint32_t ret;
    asm volatile ( "inl %1, %0"
                   : "=a"(ret)
                   : "Nd"(port) );
    return ret;
}

static inline void outl(gathrillo::common::uint16_t port, gathrillo::common::uint32_t val)
{
    asm volatile ( "outl %0, %1" : : "a"(val), "Nd"(port) );
}

static inline void io_wait(void)
{
    /* TODO: This is probably fragile. */
    asm volatile ( "jmp 1f\n\t"
                   "1:jmp 2f\n\t" "2:" );
}