#ifndef __GATHRILLO__DRIVERS__MOUSE_H
#define __GATHRILLO__DRIVERS__MOUSE_H


#include <common/types.h>
#include <drivers/driver.h>
#include <hardwarecommunication/interrupts.h>
#include <hardwarecommunication/port.h>




namespace gathrillo
{

    namespace drivers
    {

class MouseEventHandler
{
public:  
    MouseEventHandler();
   virtual void OnMouseActivate();
   virtual void OnMouseDown(gathrillo::common::uint8_t button);
   virtual void OnMouseUp(gathrillo::common::uint8_t button);
   virtual void OnMouseMove(int x, int y);
    
};

class MouseDriver : public gathrillo::hardwarecommunication::InterruptHandler, public Driver
{
    gathrillo::hardwarecommunication::Port8Bit dataport;
    gathrillo::hardwarecommunication::Port8Bit commandport;
   
   
   gathrillo::common::uint8_t buffer[3];
   gathrillo::common::uint8_t offset;
   gathrillo::common::uint8_t buttons;
   
   MouseEventHandler* handler;

   
public:
     MouseDriver(gathrillo::hardwarecommunication::InterruptManager* manager, MouseEventHandler* handler);
    ~MouseDriver();
    virtual gathrillo::common::uint32_t HandleInterrupt(gathrillo::common::uint32_t esp);
    virtual void Activate();
   
};

    }
}
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

#endif