#ifndef __GATHRILLO__MATH_H
#define __GATHRILLO__MATH_H

#include <common/types.h>

namespace ok
{
    #define MATH_PI 3.14159265358979323846

    struct MXCSR_StatusRegister
    {
        gathrillo::common::uint8_t InvalidOperationFlag : 1;
        gathrillo::common::uint8_t DenormalFlag : 1;
        gathrillo::common::uint8_t DevideByZeroFlag : 1;
        gathrillo::common::uint8_t OverflowFlag : 1;
        gathrillo::common::uint8_t UnderflowFlag : 1;
        gathrillo::common::uint8_t PrecisionFlag : 1;
        gathrillo::common::uint8_t DemormalsAreZeros : 1;
        gathrillo::common::uint8_t InvalidOperationMask : 1;
        gathrillo::common::uint8_t DenormalOperationMask : 1;
        gathrillo::common::uint8_t DevideByZeroMask : 1;
        gathrillo::common::uint8_t OverflowMask : 1;
        gathrillo::common::uint8_t UnderflowMask : 1;
        gathrillo::common::uint8_t PrecisionMask : 1;
        gathrillo::common::uint8_t RoundingControl : 2;
        gathrillo::common::uint8_t FlushToZero : 1;
        gathrillo::common::uint16_t Reserved;
    } __attribute__((packed));

    class Math
    {
    public:
        static void EnableFPU();

        static int Abs(int v);
        static double fAbs(double x);
        static int Sign(int v);
        static double sin(double x);
        static double cos(double x);
    };
}
#endif