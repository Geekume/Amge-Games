#ifndef __GATHRILLO__PACKAGE_H
#define __GATHRILLO__PACKAGE_H

#include <common/types.h>


namespace gathrillo
{


struct Package {
        
  
};


class  Sleep {

public: 
    
    Sleep();
    ~Sleep();


   
       
    
    
};



}

#endif
