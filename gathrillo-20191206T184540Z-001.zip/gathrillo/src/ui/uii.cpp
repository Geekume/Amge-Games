/*
#include <ui/uii.h>


using namespace gathrillo;
using namespace gathrillo::common;

uii::uii() 
    
: CompositeWidget(parent, ang, x,y,w,h,r,g,b,size,tri)
    
    
{
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00);     
    
gathrillo::gui::Window main(&desktop6, 9, 10, 0 , 20, 10, 0xA8 , 0xA8, 0xA8, 4); 
desktop6.AddChild(&polygon2);    

    
gathrillo::gui::Window itm1(&desktop6, 9, 40, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);     
    
    
gathrillo::gui::Window itm2(&desktop6, 9, 70, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);     
    
    
    
gathrillo::gui::Window itm3(&desktop6, 9, 100, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);     
    
    
    
gathrillo::gui::Window itm4(&desktop6, 9, 130, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);     
    
    
desktop6.Draw(&vga6);
    
    
    
}*/