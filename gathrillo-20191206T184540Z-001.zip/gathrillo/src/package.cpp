#include <package.h>
#include <common/types.h>




using namespace gathrillo;
using namespace gathrillo::common;




Sleep::Sleep()
{
 
    
}

Sleep::~Sleep()
 {
     
 }
  