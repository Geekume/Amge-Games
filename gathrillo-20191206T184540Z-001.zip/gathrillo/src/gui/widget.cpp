#include <gui/widget.h>
 
 using namespace gathrillo::common;
 using namespace gathrillo::gui;
 



int cx;
int cy;
int ch;
int cw;
bool ang90;
bool ang45;
bool ang0;
bool ang135;
bool ang180;
bool ang225;
bool ang270;
bool ang315;
bool ang360;
int a90;
int a45;
int a0;
int a135;
int a180;
int a225;
int a270;
int a315;
int a360;
int blub;
int zed1;
int zed2;
int zed3;
int zed4;


int dia1;

//k = 0;

Camera::Camera(common::uint8_t angle, common::uint8_t x, common::uint8_t y, common::uint8_t z, common::uint8_t rotx, common::uint8_t roty, common::uint8_t rotz)
:   CompositeWidget(angle, 0,0,0, w,h,r,g,b, size, tri),
    MouseEventHandler()
{
   
        
        
     blub = angle;   
        
      if(angle == 0) {
      
      ang0 = true;
      ang45 = false;
      ang90 = false;
      ang135 = false;
      ang180 = false;
      ang360 = false;   
      
        
    }   
        
        
    if(angle == 45) {
      
      ang0 = true;
      ang45 = true;
      ang90 = true;
      ang135 = false;
      ang180 = false;
      ang225 = false;
      ang270 = false;
      ang315 = false;
      ang360 = false;

        
    }     
        
        
    if(angle == 90) {
      
      ang0 = false;
      ang45 = false;
      ang90 = true;
      ang135 = false;
      ang180 = false;
      ang225 = false;
      ang270 = false;
      ang315 = false;
      ang360 = false;

      
        
    }    
        
    if(angle == 135) {
      
      ang0 = false;
      ang45 = false;
      ang90 = true;
      ang135 = true;
      ang180 = true;
      ang225 = false;
      ang270 = false;
      ang315 = false;
      ang360 = false;

      
        
    } 
        
        
    if(angle == 180) {
      
      ang0 = false;
      ang45 = false;
      ang90 = false;
      ang135 = false;
      ang180 = true;
      ang225 = false;
      ang270 = false;
      ang315 = false;
      ang360 = false;

      
        
    } 
 
  
        
    if(angle == 225) {
      
      ang0 = false;
      ang45 = false;
      ang90 = false;
      ang135 = false;
      ang180 = true;
      ang225 = true;
      ang270 = true;
      ang315 = false;
      ang360 = false;

      
        
    } 
        
        
    if(angle == 270) {
      
      ang0 = false;
      ang45 = false;
      ang90 = false;
      ang135 = false;
      ang180 = false;
      ang225 = true;
      ang270 = true;
      ang315 = false;
      ang360 = false;

      
        
    }     
        
      if(angle == 315) {
      
      ang0 = false;
      ang45 = false;
      ang90 = false;
      ang135 = false;
      ang180 = true;
      ang225 = false;
      ang270 = true;
      ang315 = true;
      ang360 = true;

      
        
    }   
      if(angle == 360) {
      
      ang0 = true;
      ang45 = false;
      ang90 = false;
      ang135 = false;
      ang180 = true;
      ang225 = false;
      ang270 = false;
      ang315 = false;
      ang360 = true;
      
        
    }   
           
        
        
        
     if(angle == 90){
       
       zed1 = z;
     }
    
   
    
     if(angle == 0){
         zed1 = 0;
         zed1 = z;
        
     }
    
  
     if(angle == 270){
       zed1 = z;
     }
    
     if(angle == 180){
      zed1 = 0;
      zed1 = z;
     }
  
        
        
        
        
        
        
        
        
        
        
    if (x == 1) {
       
       cx = 5;
       
   }   
     if (x == 2) {
       
       cx = 10;
       
   }    
         if (x == 3) {
       
       cx = 15;
       
   }
         if (x == 4) {
       
       cx = 20;
       
   }
         if (x == 5) {
       
       cx = 25;
       
   }
         if (x == 6) {
       
       cx = 30;
       
   }
         if (x == 7) {
       
       cx = 35;
       
   }
         if (x == 8) {
       
       cx = 40;
       
   }
         if (x == 9) {
       
       cx = 45;
       
   }     
  
        
        
   if (y == 1) {
       
       cy = 1;
       
   }   
     if (y == 2) {
       
       cy = 2;
       
   }    
         if (y == 3) {
       
       cy = 3;
       
   }
         if (y == 4) {
       
       cy = 4;
       
   }
         if (y == 5) {
       
       cy = 5;
       
   }
         if (y == 6) {
       
       cy = 6;
       
   }
         if (y == 7) {
       
       cy = 7;
       
   }
         if (y == 8) {
       
       cy = 8;
       
   }
         if (y == 9) {
       
       cy = 9;
       
   }      
        
        
        
if (z == 1) {
       
     //  ch = 2;
       cw = 1;
    
       
   }   
     if (z == 2) {
       
      // ch = 4;
       cw = 2;
         
       
   }    
         if (z == 3) {
       
    //   ch = 6;
       cw = 3;
       
   }
         if (z == 4) {
       
     //  ch = 8;
       cw = 4;     
       
   }
         if (z == 5) {
       
      // ch = 10;
       cw = 5;
   }
         if (z == 6) {
       
      // ch = 12;
       cw = 6;
   }
         if (z == 7) {
       
     // ch = 14;
      cw = 7; 
   }
         if (z == 8) {
       
       //ch = 16;
       cw = 8;
   }
         if (z == 9) {
       
      // ch = 18;
       cw = 9;
   }
        
        
        
        
        
        
        
        
        
}

Camera::~Camera()
{
}

void Camera::Draw(common::GraphicsContext* gc)
{
    CompositeWidget::Draw(gc);
    
   // for(int i = 0; i < 4; i++)
    //{
      //  gc -> PutPixel(MouseX-i, MouseY, 0xFF, 0xFF, 0xFF);
        //gc -> PutPixel(MouseX+i, MouseY, 0xFF, 0xFF, 0xFF);
        //gc -> PutPixel(MouseX, MouseY-i, 0xFF, 0xFF, 0xFF);
        //gc -> PutPixel(MouseX, MouseY+i, 0xFF, 0xFF, 0xFF);
    
    
    
    //}
    
    
         
}
   
 
 Widget::Widget(Widget* parent, uint8_t ang, int32_t x, int32_t y, int32_t w, int32_t h,
                                uint8_t r, uint8_t g, uint8_t b, uint8_t size, uint8_t tri)
: GameEventHandler()
 {
     this->parent = parent;
     this->x = x;
     this->y = y;
     this->w = w;
     this->h = h;
     this->r = r;
     this->g = g;
     this->b = b;
     this->tri = tri;
     this->size = size;
     this->ang = ang;
     this->Angle = blub;  
     this->z1 = zed1;  
     this->z2 = zed2;  
     this->z3 = zed3;  
     this->z4 = zed4;  


    
     this->Focussable = true;
    
    
    
     if(ang == 90){
       a90 = 90;
     }
    
     if(ang == 45){
       a45 = 45;
     }
    
     if(ang == 0){
       a0 = 0;
     }
    
     if(ang == 135){
       a135 = 135;
     }
     if(ang == 180){
       a180 = 180;
     }
    
     if(ang == 225){
       a225 = 225;
     }
     if(ang == 270){
       a270 = 270;
     }
    if(ang == 315){
       a315 = 315;
     }
    if(ang == 360){
       a360 = 360;
     }
  
 }
 
 Widget::~Widget()
 {
 }
             
 void Widget::GetFocus(Widget* widget)
 {
     if(parent != 0)
         parent->GetFocus(widget);
 }
 
 void Widget::ModelToScreen(common::int32_t &x, common::int32_t& y)
 {
     if(parent != 0)
         parent->ModelToScreen(x,y);
     x += this->x;
     y += this->y;
 }
             
 void Widget::Draw(GraphicsContext* gc)
 {
     int X = 0;
     int Y = 0;
     ModelToScreen(X,Y);
    
     
     
     
     
     if(a135 == 135 && ang135 == true){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w+cw,h+ch,r,g,b ,size, tri);
     
     }
     
     
     if(a225 == 225 && ang225 == true){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w+cw,h+ch, r,g,b ,size, tri);
     
     }
     
     if(a270 == 270 && ang270 == true){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w+cw,h+ch,r,g,b ,size, tri);
     
     }
     
     if(a315 == 315 && ang315 == true){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w+cw,h+ch,r,g,b ,size, tri);
     
     }    
     
     if(a180 == 180 && ang180 == true){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w+cw,h+ch,r,g,b ,size, tri);
     
     }
  
     if(a90 == 90 && ang90 == true){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w,h,r,g,b,size, tri);
     }
     
     if(a45 == 45 && ang45 == true ){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w,h,r,g,b ,size, tri);
     
     }
     
     if(a0 == 0 && ang0 == true ){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w+cw,h+ch,r,g,b ,size, tri);
   
     }
     if(a360 == 360 && ang360 == true ){
     
     gc->FillRectangle(X+cx+z1,Y-cy,w+cw,h+ch,r,g,b ,size, tri);
   
     }
     
     
 
     
     
 
         
    
  
 }
 

void Widget::OnMouseDown(common::int32_t x, common::int32_t y, common::uint8_t button)
 {
     if(Focussable)
         GetFocus(this);
 }
 

bool Widget::ContainsCoordinate(common::int32_t x, common::int32_t y)
 {
    return this->x <= x && x < this->x + this->w
        && this->y <= y && y < this->y + this->h;
 }
 

void Widget::OnMouseUp(common::int32_t x, common::int32_t y, common::uint8_t button)
 {
 }
 

void Widget::OnMouseMove(common::int32_t oldx, common::int32_t oldy, common::int32_t newx, common::int32_t newy)
 {
 }
 
 
 
 
 
 
 
 

 CompositeWidget::CompositeWidget(Widget* parent, common::uint8_t ang, common::uint8_t size,common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b)
: Widget(parent, ang, size, tri, x,y,w,h, r,g,b)
 {
     focussedChild = 0;
     numChildren = 0;
 }
 
 CompositeWidget::~CompositeWidget()
 {
 }
             
 void CompositeWidget::GetFocus(Widget* widget)
 {
     this->focussedChild = widget;
     if(parent != 0)
         parent->GetFocus(this);
 }
 
bool CompositeWidget::AddChild(Widget* child)
{
    if(numChildren >= 100)
        return false;
    children[numChildren++] = child;
    return true;
}


 void CompositeWidget::Draw(GraphicsContext* gc)
 {
     Widget::Draw(gc);
     for(int i = numChildren-1; i >= 0; --i)
         children[i]->Draw(gc);
 }
 
 

void CompositeWidget::OnMouseDown(int32_t x, int32_t y, common::uint8_t button)
 {
     for(int i = 0; i < numChildren; ++i)
         if(children[i]->ContainsCoordinate(x - this->x, y - this->y))
         {
            children[i]->OnMouseDown(x - this->x, y - this->y, button);
             break;
         }
 }
 
void CompositeWidget::OnMouseUp(int32_t x, int32_t y, common::uint8_t button)
 {
     for(int i = 0; i < numChildren; ++i)
         if(children[i]->ContainsCoordinate(x - this->x, y - this->y))
         {
            children[i]->OnMouseUp(x - this->x, y - this->y, button);
             break;
         }
 }
 
 void CompositeWidget::OnMouseMove(int32_t oldx, int32_t oldy, int32_t newx, int32_t newy)
 {
     int firstchild = -1;
     for(int i = 0; i < numChildren; ++i)
         if(children[i]->ContainsCoordinate(oldx - this->x, oldy - this->y))
         {
             children[i]->OnMouseMove(oldx - this->x, oldy - this->y, newx - this->x, newy - this->y);
             firstchild = i;
             break;
         }
 
     for(int i = 0; i < numChildren; ++i)
         if(children[i]->ContainsCoordinate(newx - this->x, newy - this->y))
         {
             if(firstchild != i)
                 children[i]->OnMouseMove(oldx - this->x, oldy - this->y, newx - this->x, newy - this->y);
             break;
         }
 }
 
 
void CompositeWidget::OnGameKeyDown(char str)
 {
     if(focussedChild != 0)
         focussedChild->OnGameKeyDown(str);
 }
 

void CompositeWidget::OnGameKeyUp(char str)
 {
     if(focussedChild != 0)
         focussedChild->OnGameKeyUp(str);    
}