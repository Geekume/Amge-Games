/*
#include <gui/3d_enviroment.h>

using namespace gathrillo;
using namespace gathrillo::common;
using namespace gathrillo::gui;


Camera::Camera(common::uint8_t view, common::uint8_t x, common::uint8_t y, common::uint8_t z, common::uint8_t rotx, common::uint8_t roty, common::uint8_t rotz)
:   CompositeWidget(0,0,0, w,h,r,g,b, size, tri),
    MouseEventHandler()
{
    
}

Camera::~Camera()
{
}

void Camera::Draw(common::GraphicsContext* gc)
{
    CompositeWidget::Draw(gc);
    
   // for(int i = 0; i < 4; i++)
    //{
      //  gc -> PutPixel(MouseX-i, MouseY, 0xFF, 0xFF, 0xFF);
        //gc -> PutPixel(MouseX+i, MouseY, 0xFF, 0xFF, 0xFF);
        //gc -> PutPixel(MouseX, MouseY-i, 0xFF, 0xFF, 0xFF);
        //gc -> PutPixel(MouseX, MouseY+i, 0xFF, 0xFF, 0xFF);
    //}
}
            
void Camera::OnMouseDown(gathrillo::common::uint8_t button)
{
}

void Camera::OnMouseUp(gathrillo::common::uint8_t button)
{
}

void Camera::OnMouseMove(int x, int y)
{
    x /= 3;
    y /= 3;
    
}
        
*/
