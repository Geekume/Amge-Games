#include <common/types.h>
#include <drivers/speaker.h>
#include <drivers/io.h>
#include <drivers/pit.h>

Speaker_Class Speaker;
   void printf(char* str);
    void printfHex16(gathrillo::common::uint16_t);

void Speaker_Class::tone(gathrillo::common::uint16_t frequency) {
    gathrillo::common::uint32_t Div;
 	gathrillo::common::uint8_t tmp;
 	Div = 1193180 / frequency; // Find divider
    outb(0x43, 0xb6);
 	outb(0x42, (gathrillo::common::uint16_t) (Div) );
 	outb(0x42, (gathrillo::common::uint16_t) (Div >> 8));
  
    
    printfHex16(Div);
 	tmp = inb(0x61);
  	if (tmp != (tmp | 3)) {
 		outb(0x61, tmp | 3);
 	}
    
  
}

void Speaker_Class::noTone() {
    gathrillo::common::uint8_t tmp = inb(0x61) & 0xFC;
    outb(0x61, tmp);
}

void Speaker_Class::beep() {
    tone(1000);
    PIT.delay(100);
    noTone();
}




