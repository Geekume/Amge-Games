#include <drivers/game.h>
#include <hardwarecommunication/pci.h>
#include <gui/desktop.h>
#include <gui/window.h>
#include <gui/window.h>
#include <gui/3d_enviroment.h>
#include <models/models.h>

using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;
GameEventHandler::GameEventHandler()
{
    
}
  
void GameEventHandler::OnGameKeyDown(char)
{
    
}
void GameEventHandler::OnGameKeyUp(char)
{
    
}

  GameDriver::GameDriver(InterruptManager* manager, GameEventHandler *handler)
  : InterruptHandler(0x21, manager),
    dataport(0x60),
    commandport(0x64)
  {
     this->handler = handler;
  }
  
  GameDriver::~GameDriver()
  {
  }
  
  void printf(char*);
  void printfHex(uint8_t);
  
  
  void GameDriver::Activate() 
  {
      while(commandport.Read() & 0x1)
      dataport.Read();
      commandport.Write(0xAE);
      commandport.Write(0x20);
      uint32_t status = (dataport.Read() | 1) & ~0x10;
      commandport.Write(0x60);
      dataport.Write(status);
      dataport.Write(0xf4);
  }

  uint32_t  GameDriver::HandleInterrupt(uint32_t esp)
  {
    
      uint8_t key = dataport.Read();
      if(handler == 0) 
          return esp;
     
      int i;
      int move;
      int poly;
      int cool;
      int movez3;
      int moveA;
      int moveB;
      int moveC;
      int moveD;
      
         if(key < 0x80)
      { 
      switch(key)
      {
    
 
// case 0x2A: case 0x3A: shift = true; break;
 //case 0xAA: case 0xB6: shift = false; break;       
    
        
   default:
    {
    case 0x45: break;
     printf("KEYBOARD 0x");
     printfHex(key);
     break;
      }

if(i==0) {
case 0x1C:          

move = 0;
movez3 = 0;
moveA = 0;
moveB = 0;
moveC = 0;
moveD = 0;
poly = 0;
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
    
   
    
desktop5.Draw(&vga5);
   

break;  
}
 





              
                 
if(i == 0) {               
case 0x4D:
    
    
    
    
    if(move == 360) {
    move = -90;
    
}
 

  move += 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

        
        
        
        
 // Polygon reference common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b        
        
        
      
    
        
     // desktop5.AddChild(&poly41);    

      //(90, 9, 3 , 60, 50, 9, 4, 0x00 , 0xA8, 0x00); 
      


        
        
        
        
     //gathrillo::gui::Cube bruh(gathrillo::gui::Widget::Angle, 8, 50, 60, 100, 50, 0xFE, 0xFE, 0xFE);   
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
  
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
 
        
        
              
gathrillo::models::Gardenbed ok(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE); 
        

   
desktop5.Draw(&vga5);

    }
    
   

    
break;

}


              
         
              
              
if(i == 0) {              

case 0x4B:
 if(move == 360) {
    move = -90;
    
}
 

  move -= 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

        
        
        
        
 // Polygon reference common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b        
        
        
      
    
        
     // desktop5.AddChild(&poly41);    

      //(90, 9, 3 , 60, 50, 9, 4, 0x00 , 0xA8, 0x00); 
      


        
        
        
        
     //gathrillo::gui::Cube bruh(gathrillo::gui::Widget::Angle, 8, 50, 60, 100, 50, 0xFE, 0xFE, 0xFE);   
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
  
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
 
        
        
              
gathrillo::models::Gardenbed ok(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE); 
        

   
desktop5.Draw(&vga5);

    }
    
   

    
break;

}

              
              
              
 if(i == 0) {               
case 0x48:
 if(move == 360) {
    move = -90;
    
}
 

  //move += 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

        
        
        
        
 // Polygon reference common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b        
        
        
      
    
        
     // desktop5.AddChild(&poly41);    

      //(90, 9, 3 , 60, 50, 9, 4, 0x00 , 0xA8, 0x00); 
      


        
        
        
        
     gathrillo::gui::Cube bruh(0, 8, 150, 100, 100, 50, 0xFE, 0xFE, 0xFE);   
        gathrillo::gui::Cube bruh2(90, 8, 100, 100, 100, 50, 0xFE, 0xFE, 0xFE);
        gathrillo::gui::Cube bruh3(180, 8, 100, 100, 100, 50, 0xFE, 0xFE, 0xFE);
        gathrillo::gui::Cube bruh4(270, 8, 100, 100, 100, 50, 0xFE, 0xFE, 0xFE);
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
  
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
 
        
    
   
desktop5.Draw(&vga5);

    }
    
   

    
break;

}
             

              
                 
if(i == 0) {               
case 0x50:
  
    
    
    
  
    if(move == 360) {
    move = -90;
    
}
 

 // move += 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

        
        
        
        
 // Polygon reference common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b        
        
        
      
    
        
     // desktop5.AddChild(&poly41);    

      //(90, 9, 3 , 60, 50, 9, 4, 0x00 , 0xA8, 0x00); 
      


        
        
        
        
     //gathrillo::gui::Cube bruh(gathrillo::gui::Widget::Angle, 8, 50, 60, 100, 50, 0xFE, 0xFE, 0xFE);   
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
  
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
 
        
        
              
gathrillo::models::Gardenbed ok(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE); 
        

   
desktop5.Draw(&vga5);

    }
    
   

    
break;

}

              
              
              
              
              
              
              
              
              
              
              
      }
               
             
             
}
      return esp;
}
 


