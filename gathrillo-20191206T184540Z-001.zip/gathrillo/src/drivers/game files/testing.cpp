#include <drivers/game.h>
#include <hardwarecommunication/pci.h>
#include <gui/desktop.h>
#include <gui/window.h>

using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;






GameEventHandler::GameEventHandler()
{
    
}
  
void GameEventHandler::OnGameKeyDown(char)
{
    
}
void GameEventHandler::OnGameKeyUp(char)
{
    
}







  GameDriver::GameDriver(InterruptManager* manager, GameEventHandler *handler)
  : InterruptHandler(0x21, manager),
    dataport(0x60),
    commandport(0x64)
  {
     this->handler = handler;
  }
  
  GameDriver::~GameDriver()
  {
  }
  
  void printf(char*);
  void printfHex(uint8_t);
  
  
  void GameDriver::Activate() 
  {
      while(commandport.Read() & 0x1)
          dataport.Read();
      commandport.Write(0xAE);
      commandport.Write(0x20);
      uint32_t status = (dataport.Read() | 1) & ~0x10;
      commandport.Write(0x60);
      dataport.Write(status);
      dataport.Write(0xf4);
  }
  
    


  uint32_t  GameDriver::HandleInterrupt(uint32_t esp)
  {
    
      uint8_t key = dataport.Read();
      if(handler == 0) 
          return esp;
      
      static bool shift = false;
      static bool pci = false;
      static bool black = false;
      static bool ok = true;
      static int i = 0;
      int x;
      int e;
      int y;
      int d;
      int s;
      int ax;
      int ay;
      
      //////////////////////////
      int bx;
      int by;
      int cx;
      int cy;
      int lx;
      int ly;
      int scroll;
      int select1;
      int select2;
      int color;
      int z; 
     
      
   
      
         if(key < 0x80)
      { 
      switch(key)
      {
    
    
    
    
    case 0x1E: if(shift) handler->OnGameKeyDown('A'); else handler->OnGameKeyDown('a'); break;
    case 0x30: if(shift) handler->OnGameKeyDown('B'); else handler->OnGameKeyDown('b'); break;
    case 0x2E: if(shift) handler->OnGameKeyDown('C'); else handler->OnGameKeyDown('c'); break; 
    case 0x20: if(shift) handler->OnGameKeyDown('D'); else handler->OnGameKeyDown('d'); break;
    //case 0x12: if(shift) handler->OnGameKeyDown('E'); else handler->OnGameKeyDown('e'); break;
    case 0x21: if(shift) handler->OnGameKeyDown('F'); else handler->OnGameKeyDown('f'); break;
    case 0x22: if(shift) handler->OnGameKeyDown('G'); else handler->OnGameKeyDown('g'); break;
    case 0x23: if(shift) handler->OnGameKeyDown('H'); else handler->OnGameKeyDown('h'); break;
    case 0x17: if(shift) handler->OnGameKeyDown('I'); else handler->OnGameKeyDown('i'); break;
    case 0x24: if(shift) handler->OnGameKeyDown('J'); else handler->OnGameKeyDown('j'); break;
    case 0x25: if(shift) handler->OnGameKeyDown('K'); else handler->OnGameKeyDown('k'); break;
    case 0x26: if(shift) handler->OnGameKeyDown('L'); else handler->OnGameKeyDown('l'); break;
    case 0x32: if(shift) handler->OnGameKeyDown('M'); else handler->OnGameKeyDown('m'); break;
    case 0x31: if(shift) handler->OnGameKeyDown('N'); else handler->OnGameKeyDown('n'); break;
    case 0x18: if(shift) handler->OnGameKeyDown('O'); else handler->OnGameKeyDown('o'); break;
    case 0x19: if(shift) handler->OnGameKeyDown('P'); else handler->OnGameKeyDown('p'); break;
    //case 0x10: if(shift) handler->OnGameKeyDown('Q'); else handler->OnGameKeyDown('q'); break;
    //case 0x13: if(shift) handler->OnGameKeyDown('R'); else handler->OnGameKeyDown('r'); break;
    case 0x1F: if(shift) handler->OnGameKeyDown('S'); else handler->OnGameKeyDown('s'); break;
    case 0x14: if(shift) handler->OnGameKeyDown('T'); else handler->OnGameKeyDown('t'); break;
    case 0x16: if(shift) handler->OnGameKeyDown('U'); else handler->OnGameKeyDown('u'); break;
    case 0x2F: if(shift) handler->OnGameKeyDown('V'); else handler->OnGameKeyDown('v'); break;
    //case 0x11: if(shift) handler->OnGameKeyDown('W'); else handler->OnGameKeyDown('w'); break;
    case 0x2D: if(shift) handler->OnGameKeyDown('X'); else handler->OnGameKeyDown('x'); break;
    case 0x15: if(shift) handler->OnGameKeyDown('Y'); else handler->OnGameKeyDown('y'); break;
    case 0x2C: if(shift) handler->OnGameKeyDown('Z'); else handler->OnGameKeyDown('z'); break;
    case 0x0B: if(shift) handler->OnGameKeyDown(')'); else handler->OnGameKeyDown('0'); break;
    //case 0x02: if(shift) handler->OnGameKeyDown('!'); else handler->OnGameKeyDown('1'); break;
    //case 0x03: if(shift) handler->OnGameKeyDown('@'); else handler->OnGameKeyDown('2'); break;
    //case 0x04: if(shift) handler->OnGameKeyDown('#'); else handler->OnGameKeyDown('3'); break;
    //case 0x05: if(shift) handler->OnGameKeyDown('$'); else handler->OnGameKeyDown('4'); break;
    //case 0x06: if(shift) handler->OnGameKeyDown('%'); else handler->OnGameKeyDown('5'); break;
    //case 0x07: if(shift) handler->OnGameKeyDown('^'); else handler->OnGameKeyDown('6'); break;
    //case 0x08: if(shift) handler->OnGameKeyDown('&'); else handler->OnGameKeyDown('7'); break;
   // case 0x09: if(shift) handler->OnGameKeyDown('*'); else handler->OnGameKeyDown('8'); break;
    case 0x0A: if(shift) handler->OnGameKeyDown('('); else handler->OnGameKeyDown('9'); break;
    case 0x0C: if(shift) handler->OnGameKeyDown('_'); else handler->OnGameKeyDown('-'); break;
    case 0x0D: if(shift) handler->OnGameKeyDown('+'); else handler->OnGameKeyDown('='); break;
    case 0x1A: if(shift) handler->OnGameKeyDown('{'); else handler->OnGameKeyDown('['); break;
    case 0x1B: if(shift) handler->OnGameKeyDown('}'); else handler->OnGameKeyDown(']'); break;
    case 0x2B: if(shift) handler->OnGameKeyDown('|'); else handler->OnGameKeyDown('|'); break;
    case 0x27: if(shift) handler->OnGameKeyDown(':'); else handler->OnGameKeyDown(';'); break;
    case 0x28: if(shift) printf(" "); else handler->OnGameKeyDown(' " '); break;
    case 0x33: if(shift) handler->OnGameKeyDown('<'); else handler->OnGameKeyDown(','); break;
    case 0x34: if(shift) handler->OnGameKeyDown('>'); else handler->OnGameKeyDown('.'); break;
    case 0x35: if(shift) handler->OnGameKeyDown('?'); else handler->OnGameKeyDown('/'); break;
    case 0x29: if(shift) handler->OnGameKeyDown('~'); else handler->OnGameKeyDown('`'); break;
   // case 0x39: if(shift) printf(""); else printf(" "); y = y - 20; break;
    //case 0x1C: if(shift) handler->OnGameKeyDown('\n'); else handler->OnGameKeyDown('\n'); break;
  
          
    
    
    
   
// case 0x2A: case 0x3A: shift = true; break;
 //case 0xAA: case 0xB6: shift = false; break;       
    
        
   default:
    {
    case 0x45: break;
     printf("KEYBOARD 0x");
     printfHex(key);
     break;
      }
  



   
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
           

              
              
     

if(i == 0) {              

case 0x10:
            
    
    
    
    
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
 
    
    
    
    
    
        
    
         gathrillo::gui::Window win1(&desktop5, 10, 112.5, 60, 60, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&win1);
    
    
     gathrillo::gui::Window win2(&desktop5, 90, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win2);
    
    
     gathrillo::gui::Window win3(&desktop5, 170, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win3);
    
    
     gathrillo::gui::Window win4(&desktop5, 250, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win4);
         
     // Main Screen
    
     gathrillo::gui::Window win5(&desktop5, 10, 5, 300, 100, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win5);
    
    
    
    
    
desktop5.Draw(&vga5);


break;

}
 
              



              
              
              
if(i == 0) {              

case 0x11:
            
    
    
    
    
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
 
    
        
    
         gathrillo::gui::Window win1(&desktop5, 10, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win1);
    
    
     gathrillo::gui::Window win2(&desktop5, 90, 112.5, 60, 60, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&win2);
    
    
     gathrillo::gui::Window win3(&desktop5, 170, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win3);
    
    
     gathrillo::gui::Window win4(&desktop5, 250, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win4);
         
     // Main Screen
    
     gathrillo::gui::Window win5(&desktop5, 10, 5, 300, 100, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win5);
    
    
    
    
    
desktop5.Draw(&vga5);


break;

}

              





              
if(i == 0) {              

case 0x02:
            
    
    
    
    
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop(320,200, 0xA8,0x00,0xA8);            
 
    
        
    
    
    
    //3D
    
   
    
    
    //line 1
     gathrillo::gui::Window win20(&desktop, 141, 40, 19, 19, 0xFF, 0x00, 0x00);
     desktop.AddChild(&win20);

     
     
     
    
     gathrillo::gui::Window win200(&desktop, 140, 40, 1, 20, 0x00, 0x00, 0x00);
     win20.AddChild(&win200);
     
    
     
     
     gathrillo::gui::Window win201(&desktop, 140, 59, 20, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win201);
     
     
     
     gathrillo::gui::Window win21(&desktop, 140, 39, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win21);
    
    
     gathrillo::gui::Window win22(&desktop, 141, 38, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win22);
    
     gathrillo::gui::Window win23(&desktop, 142, 37, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win23);
    
    
     gathrillo::gui::Window win24(&desktop, 143, 36, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win24);
    
     gathrillo::gui::Window win25(&desktop, 144, 35, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win25);
    
    
     gathrillo::gui::Window win26(&desktop, 145, 34, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win26);
    
    //////
     
    //fill line 2
     
    gathrillo::gui::Window win160(&desktop, 160, 40, 1, 19, 0x00, 0x00, 0x00);
     win20.AddChild(&win160);
     
     gathrillo::gui::Window win161(&desktop, 161, 39, 1, 19, 0xA8, 0x00, 0x00);
     win20.AddChild(&win161);
     
     gathrillo::gui::Window win162(&desktop, 162, 38, 1, 19, 0xA8, 0x00, 0x00);
     win20.AddChild(&win162);
     
     gathrillo::gui::Window win163(&desktop, 163, 37, 1, 19, 0xA8, 0x00, 0x00);
     win20.AddChild(&win163);
     
     
     gathrillo::gui::Window win164(&desktop, 164, 36, 1, 19, 0xA8, 0x00, 0x00);
     win20.AddChild(&win164);
     
     
     gathrillo::gui::Window win165(&desktop, 165, 35, 1, 19, 0x00, 0x00, 0x00);
     win20.AddChild(&win165);
     
     ///////
     
     //fill line 1
  
    
     
     
     gathrillo::gui::Window win168(&desktop, 145, 34, 20, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win168);
     
     
     
     gathrillo::gui::Window win169(&desktop, 144, 35, 20, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win169);
     
    
     gathrillo::gui::Window win170(&desktop, 143, 36, 20, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win170);
     
     
     
     gathrillo::gui::Window win171(&desktop, 142, 37, 20, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win171);
     
     
     
     gathrillo::gui::Window win172(&desktop, 141, 38, 20, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win172);
     
     
     
     gathrillo::gui::Window win173(&desktop, 140, 39, 20, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win173);
      
     
    
    
    //////
    
    
    // line 2
    
    gathrillo::gui::Window win27(&desktop, 160, 39, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win27);
    
    
     gathrillo::gui::Window win28(&desktop, 161, 38, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win28);
    
     gathrillo::gui::Window win29(&desktop, 162, 37, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win29);
    
    
     gathrillo::gui::Window win30(&desktop, 163, 36, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win30);
    
     gathrillo::gui::Window win31(&desktop, 164, 35, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win31);
    
    
     gathrillo::gui::Window win32(&desktop, 165, 34, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win32);
    
    
    // line 3
    
     gathrillo::gui::Window win33(&desktop, 160, 59, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win33);
    
    
     gathrillo::gui::Window win34(&desktop, 161, 58, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win34);
    
     gathrillo::gui::Window win35(&desktop, 162, 57, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win35);
    
    
     gathrillo::gui::Window win36(&desktop, 163, 56, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win36);
    
     gathrillo::gui::Window win37(&desktop, 164, 55, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win37);
    
    
     gathrillo::gui::Window win38(&desktop, 165, 54, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win38);
 
    
    
    
    
    // connect line 2
    
    

    
    
      gathrillo::gui::Window win59(&desktop, 165, 37, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win59);
    
      gathrillo::gui::Window win60(&desktop, 165, 34, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win60);
    
    
      gathrillo::gui::Window win61(&desktop, 165, 35, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win61);
    
    
      gathrillo::gui::Window win62(&desktop, 165, 36, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win62);
    
    
      gathrillo::gui::Window win63(&desktop, 165, 37, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win63);
    
    
    
    
     gathrillo::gui::Window win64(&desktop, 165, 38, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win64);
    
      gathrillo::gui::Window win65(&desktop, 165, 39, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win65);
    
    
      gathrillo::gui::Window win66(&desktop, 165, 40, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win66);
    
    
      gathrillo::gui::Window win67(&desktop, 165, 41, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win67);
    
    
      gathrillo::gui::Window win68(&desktop, 165, 42, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win68);
    
    
    
    
     gathrillo::gui::Window win69(&desktop, 165, 43, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win69);
    
     gathrillo::gui::Window win70(&desktop, 165, 44, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win70);
    
    
     gathrillo::gui::Window win71(&desktop, 165, 45, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win71);
    
    
     gathrillo::gui::Window win72(&desktop, 165, 46, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win72);
    
    
     gathrillo::gui::Window win73(&desktop, 165, 47, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win73);
    
    
     gathrillo::gui::Window win74(&desktop, 165, 48, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win74);
    
     gathrillo::gui::Window win75(&desktop, 165, 49, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win75);
    
    
     gathrillo::gui::Window win76(&desktop, 165, 50, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win76);
    
    
     gathrillo::gui::Window win77(&desktop, 165, 51, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win77);
    
    
     gathrillo::gui::Window win78(&desktop, 165, 52, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win78);
     
     gathrillo::gui::Window win79(&desktop, 165, 53, 1, 1, 0x00, 0x00, 0x00);
     win20.AddChild(&win79);
    
   
     
     
     
     
     
      
    // Fill in line 5
    
    

    /*
    
      gathrillo::gui::Window win160(&desktop, 164, 37, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win160);
    
      gathrillo::gui::Window win170(&desktop, 164, 34, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win170);
    
    
      gathrillo::gui::Window win171(&desktop, 164, 35, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win171);
    
    
      gathrillo::gui::Window win172(&desktop, 164, 36, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win171);
    
    
      gathrillo::gui::Window win173(&desktop, 164, 37, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win173);
    
    
    
    
     gathrillo::gui::Window win174(&desktop, 164, 38, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win174);
    
      gathrillo::gui::Window win175(&desktop, 164, 39, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win175);
    
    
      gathrillo::gui::Window win176(&desktop, 164, 40, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win176);
    
    
      gathrillo::gui::Window win177(&desktop, 164, 41, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win177);
    
    
      gathrillo::gui::Window win178(&desktop, 164, 42, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win178);
    
    
    
    
     gathrillo::gui::Window win179(&desktop, 164, 43, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win179);
    
     gathrillo::gui::Window win180(&desktop, 164, 44, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win180);
    
    
     gathrillo::gui::Window win181(&desktop, 164, 45, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win181);
    
    
     gathrillo::gui::Window win182(&desktop, 164, 46, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win182);
    
    
     gathrillo::gui::Window win183(&desktop, 164, 47, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win183);
    
    
     gathrillo::gui::Window win184(&desktop, 164, 48, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win184);
    
     gathrillo::gui::Window win185(&desktop, 164, 49, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win75);
    
    
     gathrillo::gui::Window win186(&desktop, 164, 50, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win186);
    
    
     gathrillo::gui::Window win187(&desktop, 164, 51, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win187);
    
    
     gathrillo::gui::Window win188(&desktop, 164, 52, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win188);
     
     gathrillo::gui::Window win189(&desktop, 164, 53, 1, 1, 0xA8, 0x00, 0x00);
     win20.AddChild(&win9);*/
    
     
     
     
     // Fill in line 5
     
    
     





    
    
    
    
desktop.Draw(&vga5);


break;

}


     
if(i == 0) {              

case 0x03:
        
   

    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xFF,0xFF,0xFF); 



    
desktop5.Draw(&vga5);

    
break;
}





  if(i == 0) {              

case 0x12:
            
    
    
    
    
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
 
    
        
    
         gathrillo::gui::Window win1(&desktop5, 10, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win1);
    
    
     gathrillo::gui::Window win2(&desktop5, 90, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win2);
    
    
     gathrillo::gui::Window win3(&desktop5, 170, 112.5, 60, 60, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&win3);
    
    
     gathrillo::gui::Window win4(&desktop5, 250, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win4);
         
     // Main Screen
    
     gathrillo::gui::Window win5(&desktop5, 10, 5, 300, 100, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win5);
    
    
    
    
    
desktop5.Draw(&vga5);


break;

}            
              
              
              


              
if(i == 0) {              

case 0x13:
            
    
    
    
    
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
 
        
    
     gathrillo::gui::Window win1(&desktop5, 10, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win1);
    
    
     gathrillo::gui::Window win2(&desktop5, 90, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win2);
    
    
     gathrillo::gui::Window win3(&desktop5, 170, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win3);
    
    
     gathrillo::gui::Window win4(&desktop5, 250, 112.5, 60, 60, 0xFD, 0xFD, 0xFD);
     desktop5.AddChild(&win4);
         
     // Main Screen
    
     gathrillo::gui::Window win5(&desktop5, 10, 5, 300, 100, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win5);
    
    
    
    
    
desktop5.Draw(&vga5);


break;

}



     
              
  
if(i == 54) {
    //case 0x50 : 
    
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
     
          
    
      
    //row 1
gathrillo::gui::Window win1(&desktop5, 10, 100, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win1);
    
    
     gathrillo::gui::Window win2(&desktop5, 90, 100, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win2);
    
    
     gathrillo::gui::Window win3(&desktop5, 170, 100, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win3);
    
    
     gathrillo::gui::Window win4(&desktop5, 250, 100, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win4);
 
    //row 2
    
    gathrillo::gui::Window win5(&desktop5, 10, 20, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win5);
    
    
     gathrillo::gui::Window win6(&desktop5, 90, 20, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win6);
    
    
     gathrillo::gui::Window win7(&desktop5, 170, 20, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win7);
    
    
     gathrillo::gui::Window win8(&desktop5, 250, 20, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win8);
         
    
    
    
desktop5.Draw(&vga5);
    break;
}
    
    
    if(i == 0) {              

case 0x2A: 
//case 0x3A:

            
    
    
    
    
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
 
         vga5.FillRectangle(0,0,80,20,0xFE,0xFE,0xFE);
    vga5.FillRectangle(80,0,1,20,0x00,0x00,0x00);
    
    
    vga5.FillRectangle(81,0,80,20,0xFE,0xFE,0xFE);
    vga5.FillRectangle(161,0,1,20,0x00,0x00,0x00);
    
    vga5.FillRectangle(162,0,80,20,0xFE,0xFE,0xFE);
    vga5.FillRectangle(242,0,1,20,0x00,0x00,0x00);
    
    
    vga5.FillRectangle(243,0,80,20,0xFE,0xFE,0xFE);
    
    
    
    
    
    vga5.FillRectangle(0,20,320,1,0x00,0x00,0x00);
    
    vga5.FillRectangle(0,199,320,1,0x00,0x00,0x00);
    
    
         gathrillo::gui::Window win1(&desktop5, 10, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win1);
    
    
     gathrillo::gui::Window win2(&desktop5, 90, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win2);
    
    
     gathrillo::gui::Window win3(&desktop5, 170, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win3);
    
    
     gathrillo::gui::Window win4(&desktop5, 250, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win4);
         
     // Main Screen
    
     gathrillo::gui::Window win5(&desktop5, 10, 5, 300, 100, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win5);
    
    
    
    
    
desktop5.Draw(&vga5);


break;

}             


         
 

  
              
e = 30;        
          
 if(i == 0) {  

case 0x1c: 


e = e + 10; 

if (e == 30) {
    x = 0;
}
     
if(e == 40) {
    e = 0;
    x = 400;
}

if (e == 20) {
    x = 340;
    
}
 
if (e == 10) {
    x = 400;
    
}
 

     


     
if(e == 10) 
{
              
 
            
 VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0xA8,0x00,0xA8);            
 
    vga5.FillRectangle(0,0,80,20,0xFE,0xFE,0xFE);
    vga5.FillRectangle(80,0,1,20,0x00,0x00,0x00);
    
    
    vga5.FillRectangle(81,0,80,20,0xFE,0xFE,0xFE);
    vga5.FillRectangle(161,0,1,20,0x00,0x00,0x00);
    
    vga5.FillRectangle(162,0,80,20,0xFE,0xFE,0xFE);
    vga5.FillRectangle(242,0,1,20,0x00,0x00,0x00);
    
    
    vga5.FillRectangle(243,0,80,20,0xFE,0xFE,0xFE);
    
    
    
    
    
    vga5.FillRectangle(0,20,320,1,0x00,0x00,0x00);
    
    vga5.FillRectangle(0,199,320,1,0x00,0x00,0x00);
    
        
    
         gathrillo::gui::Window win1(&desktop5, 10, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win1);
    
    
     gathrillo::gui::Window win2(&desktop5, 90, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win2);
    
    
     gathrillo::gui::Window win3(&desktop5, 170, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win3);
    
    
     gathrillo::gui::Window win4(&desktop5, 250, 112.5, 60, 60, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win4);
         
     // Main Screen
    
     gathrillo::gui::Window win5(&desktop5, 10, 5, 300, 100, 0xFE, 0xFE, 0xFE);
     desktop5.AddChild(&win5);
    
    
    
    
    
desktop5.Draw(&vga5);



    
  
    
    
    
    


x = 400;
           
}     
     
    
break;
 }
 
 
     
 
              
              
                       
         
 
              
              
              
              
              
              
              
              
 int a1; 
 int a2;
              
              

               
if (i == 0) {

case 0x50:
 
   
    
if (e == 20)  {
    
   select2 = 0xFD;
   select1 = 0xFE;
   e = 30;
}

    
 
    
    
    
break;

}

    
if(i == 0) {

case 0x48:
 
   
    
  while (e == 20)  {
    
   select1 = 0xFD;
   select2 = 0xFE;
   e = 30;
  
      
    
}
 


    
    
  
 break;

}

   if(i == 0) {

case 0x500:
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle( ax = 100, ay = 50,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
 
    
    
    while(lx < 50) {
    
    lx = ax;
    ax = ax + 10;
    
    
    
    
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle(ax = 100, ay = 50,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
} 
    
    
    
    
    
    
    
    
    
    
    
  
  /// idea take one 
    
    
    while (ay == 50 && lx < bx) {
        
        
        
        
      
          
          
        lx = lx + 3;
        vga5.FillRectangle(lx,ly,9,2,0x00,0x00,0x00); 
        
  
          
     
        ly = ly + 1;  
          
    
          
     
        
       
        
       
    } 
      
    
    
    
    
    
    
desktop5.Draw(&vga5);    
    
    
    
}                  
   

 if(i == 0) {

case 0x04:

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle( ax = 100, ay = 40,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
 
    
    
    while(lx < 50) {
    
    lx = ax;
    ax = ax + 10;
    
    
    
    
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle(ax = 100, ay = 80,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
} 
    
    
    
    
    
    
    
    
    
    
    
  
  /// idea take one 
    
    
    while (ay == 90 && lx < bx) {
        
        
        
        
      
          
          
        lx = lx + 9;
        vga5.FillRectangle(lx,ly,9,1,0x00,0x00,0x00); 
        
  
          
     
        ly = ly + 1;  
          
    
          
     
        
       
        
       
    } 
      
    
      while (ay == 80 && lx < bx - 5) {
        
        
        
        
      
          
          
        lx = lx + 1;
        vga5.FillRectangle(lx,ly,5,2,0x00,0x00,0x00); 
        
       
          
     
        
    
            
        ly = ly + 2;  
 
      
            
        
          
          
         
          
      
        
       
        
       
    } 
    
    
    
      
 while (ly == by && lx < bx) {
     
     lx = lx + 1;
     
     vga5.FillRectangle(lx,ly,1,1,0x00,0x00,0x00);
    
   
 }
    
    
  
    
    
    
    
    
    
    
    
desktop5.Draw(&vga5);    
    
    
    
}                    
              
              
              
if(i == 0) {

case 0x06:
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle( ax = 100, ay = 60,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
 
    
    
    while(lx < 50) {
    
    lx = ax;
    ax = ax + 10;
    
    
    
    
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle(ax = 100, ay = 90,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
} 
    
    
    
    
    
    
    
    
    
    
    
  
  /// idea take one 
    
    
    while (ay == 60 && lx < bx) {
        
        
        
        
      
        
          
        lx = lx + 5 ;
        
        vga5.FillRectangle(lx,ly, 6,2,0x00,0x00,0x00); 
        
  
          
     
        ly = ly + 2;  
          
    
          
     
        
       
        
       
    } 
      
    
     
desktop5.Draw(&vga5);    
    
    
    
}      
              
              
 if(i == 0) {

case 0x70:
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle( ax = 100, ay = 70,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
 
    
    
    while(lx < 50) {
    
    lx = ax;
    ax = ax + 10;
    
    
    
    
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle(ax = 100, ay = 90,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
} 
    
    
    
    
    
    
    
    
    
    
    
  
  /// idea take one 
    
    
    while (ay == 70 && lx < bx) {
        
        
        
        
      
          
          
        lx = lx + 7;
        vga5.FillRectangle(lx,ly,7,2,0x00,0x00,0x00); 
        
  
          
     
        ly = ly + 2;  
          
    
          
     
        
       
        
       
    } 
      
    
     
    
    
desktop5.Draw(&vga5);    
    
    
    
}      
              
if(i == 0) {

case 0x80:
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle( ax = 100, ay = 80,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
 
    
    
    while(lx < 50) {
    
    lx = ax;
    ax = ax + 10;
    
    
    
    
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle(ax = 100, ay = 90,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
} 
    
    
    
    
    
    
    
    
    
    
    
  
  /// idea take one 
    
    
   
      
    
      while (ay == 80 && lx < bx - 5) {
        
        
        
        
      
          
          
        lx = lx + 5;
        vga5.FillRectangle(lx,ly,5,2,0x00,0x00,0x00); 
        
       
          
     
        
    
            
        ly = ly + 1;  
 
    } 
    
    
    
      
 
    
    
    
    
desktop5.Draw(&vga5);    
    
    
    
}      

if(i==0) {              
              
case 0x90:
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle( ax = 100, ay = 90,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
 
    
    
    while(lx < 50) {
    
    lx = ax;
    ax = ax + 10;
    
    
    
    
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle(ax = 100, ay = 90,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
} 
    
    
    
    
    
    
    
    
    
    
    
  
  /// idea take one 
    
    
    while (ay == 90 && lx < bx) {
        
        
        
        
      
          
          
        lx = lx + 9;
        vga5.FillRectangle(lx,ly,9,2,0x00,0x00,0x00); 
        
  
          
     
        ly = ly + 1;  
          
    
          
     
        
       
        
       
    } 
      
    
    
    
  
    
desktop5.Draw(&vga5);    
    
    
    
} 

if (i == 0) {            
             
case 0x100:
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle( ax = 100, ay = 100,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
 
    
    
    while(lx < 50) {
    
    lx = ax;
    ax = ax + 10;
    
    
    
    
    VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);    
gathrillo::gui::Desktop desktop5(0,1, 0xFF,0xFF,0xFF);            
    
    
    
         
    
    
    
    
 
    vga5.FillRectangle(0,0,320,200,0xFf,0xFF,0xFF);
    
    
       ////////////////////////////////////////
 
    
    
    
    
    vga5.FillRectangle(ax = 100, ay = 100,1,1,0x00,0x00,0x00);
  
    vga5.FillRectangle(bx = 200, by = 100,1,1,0x00,0x00,0x00);
        
  
    
    
 

    lx = ax;
        
    ly = ay;
} 
    
    
    
    
    
    
    
    
    
    
    
  
  /// idea take one 
    
    
  
      
 while (ay == 100 && lx < bx) {
     
     lx = lx + 1;
     
     vga5.FillRectangle(lx,ly,1,2,0x00,0x00,0x00);
    
   
 }
    
    
  
    
    
    
    
    
    
   
    
desktop5.Draw(&vga5);    
         
         
}
  
              
 if(i==0) {              
 case 0x09:
 
  VideoGraphicsArray vga5;
 vga5.SetMode(320,200,8);
 gathrillo::gui::Desktop desktop5(320,200, 0xFF,0xFF,0xFF);            
  
         
     
       gathrillo::gui::Window line1(&desktop5, 100, 100, 0 , 0, 0xA8, 0x00, 0x00);
      desktop5.AddChild(&line1);    
     
     
    desktop5.Draw(&vga5);  
break;
 }
              
      }
        
             
}
      return esp;
}
 


