
#include <drivers/hopeidontfail.h>
using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;






sqrtfun::sqrtfun( double sqrt)   
{
    
//sqrt1 = 2.0; 
/*    
sqrt(1.0) = 1.0; 
sqrt(2) = 1.4142; 
sqrt(3) = 1.7321; 
sqrt(4) = 2.0; 
sqrt(5) = 2.2361; 
sqrt(6) = 2.4494; 
sqrt(7) = 2.6457; 
sqrt(8) = 2.8284; 
sqrt(9) = 3.0; 
sqrt(10) = 3.1622; 
 */
    
}

sqrtfun::~sqrtfun(){}


sin::sin() 
  
    
{

        
}

sin::~sin(){}


cos::cos(common::uint8_t number) 
  
    
{

        
}

cos::~cos(){}