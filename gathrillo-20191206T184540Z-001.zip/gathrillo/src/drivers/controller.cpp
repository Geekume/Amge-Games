// #include <drivers/controller.h>
// using namespace gathrillo::drivers;
// 
//   ControllerDriver::ControllerDriver(InterruptManager* manager)
//   : InterruptHandler(0x91, manager),
//     dataport(0x60),
//     commandport(0x64)
//   {
//        static uint16_t* VideoMemory = (uint16_t*)0xb8000;
//             VideoMemory[80*12+40] = (((VideoMemory[80*12+40]) & 0xF000) >> 4)
//                               | (((VideoMemory[80*12+40]) & 0x0F00) << 4)
//                               | ((VideoMemory[80*12+40]) & 0x00FF);
//       
//       commandport.Write(0xA8);
//       commandport.Write(0x20);
//       uint32_t status = dataport.Read() | 2;
//       commandport.Write(0x60);
//       dataport.Write(status);
//       
//       commandport.Write(0xD4);
//       dataport.Write(0xF4);
//       dataport.Read();
//   }
//   
//   ControllerDriver::~ControllerDriver()
//   {
//   }
//   
//   void printf(char*);
//   
//   uint32_t  ControllerDriver::HandleInterrupt(uint32_t esp)
//   {
//       uint8_t key = dataport.Read();
//   
//     
// 
//     
//     
//      char* foo = "Controller 0x00 ";
//      char* hex = "0123456789ABCDEF";
//      foo[11] = hex[(key >> 4) & 0x0F];
//      foo[12] = hex[key & 0x0F];
//      
//      printf(foo);
//       
//      return esp;
// }
//     
//    