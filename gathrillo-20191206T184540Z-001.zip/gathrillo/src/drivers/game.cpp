#include <drivers/game.h>
#include <hardwarecommunication/pci.h>
#include <gui/desktop.h>
#include <gui/window.h>
#include <drivers/io.h>
#include <models/models.h>
#include <drivers/ata.h>
#include <drivers/math.h>






using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;

    
    


GameEventHandler::GameEventHandler()
{
    
}
  
void GameEventHandler::OnGameKeyDown(char)
{
    
}
void GameEventHandler::OnGameKeyUp(char)
{
    
}

  GameDriver::GameDriver(InterruptManager* manager, GameEventHandler *handler)
  : InterruptHandler(0x21, manager),
    dataport(0x60),
    commandport(0x64)
  {
     this->handler = handler;
    
    
  }
  
  GameDriver::~GameDriver()
  {
  }
  
  void printf(char*);
  void printfHex(uint8_t);
  
  
  void GameDriver::Activate() 
  {
      while(commandport.Read() & 0x1)
      dataport.Read();
      commandport.Write(0xAE);
      commandport.Write(0x20);
      uint32_t status = (dataport.Read() | 1) & ~0x10;
      commandport.Write(0x60);
      dataport.Write(status);
      dataport.Write(0xf4);
  }




   

      
  


  uint32_t  GameDriver::HandleInterrupt(uint32_t esp)
  {
    
      uint8_t key = dataport.Read();
      if(handler == 0) 
          return esp;
     
      int i;
      int move;
      int poly;
      int cool;
      int movez3;
      int moveA;
      int moveB;
      int moveC;
      int moveD;
      int skelsize;
      int oof;
      int objscale;
      int flash;
      int svx;
      int svy;
      int ANGSHIFT;
      int tranz;
      int id;
      int defZ;
      int xui;
      int yui;
      int Lev;
      int xok;
      int run1;
      int run2;
      int jumpspeed;
      int runs;
      int resize;
      int levelselect;
      bool repeat;
      int walk;
      int health;
      int health2;
      int enemypos;
      int menu;
      
    
      
      
      
     if(flash == 1) {   
 
     
      
    save[1] = it1;
    save[2] = it2;
    save[3] = it3;
    save[4] = it4;
    save[5] = it5;
    save[6] = it6;
    save[7] = it7;
    save[8] = it8;
    
   //xtgit375   
    s1 = save[1], save[2],save[3],save[4],save[5],save[6],save[7],save[8];
    AdvancedTechnologyAttachment ata0s(false, 0x1F0); 
    ata0s.Write28(0, (uint8_t*)s1 , 16);
    ata0s.Flush();

      
      
      flash = 2;
      
      
     }
      
      
      
      
      
      
    
      
         if(key < 0x80)
      { 
      switch(key)
      {
    
 
// case 0x2A: case 0x3A: shift = true; break;
 //case 0xAA: case 0xB6: shift = false; break;       
    
        
   default:
    {
    case 0x45: break;
     printf("KEYBOARD 0x");
     printfHex(key);
     break;
      }

              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
if(i==0) {
case 0x36:          

    
    
move = 0;
movez3 = 0;
moveA = 0;
moveB = 0;
moveC = 0;
moveC = 0;
moveD = 0;
poly = 0;
skelsize = 0;  
objscale = 3;
ANGSHIFT = 0;
tranz = 0;
oof = 0;
defZ = 0;
        
xui = 220;
yui = 130;
xok = 0;
run1 = 0;
run2 = 2;
jumpspeed = 0;
runs = 0;
resize = 0;
levelselect = 1;
repeat = false;
walk = 50;
health = 100;
health2 = 100; 
enemypos = 100;
menu = 0;
    


if(menu != 20) {

VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(320,200, 0x00,0x00,0x00); 
    

    
        
gathrillo::gui::ui ui();  
        
  gathrillo::gui::Window itm4(&desktop5, 0, 130, 100 , 20, 10, 0x00 , 0x00, 0x00, 4); 
desktop5.AddChild(&itm4);     
    

    

    
    
    
desktop5.Draw(&vga5);
   
    
    
      }
   
     
    
    
   
    

break;  
}
              
           
              
if(i==0) {
case 0x1C:          

  

if(menu == 1)
menu = 40;
    
    
if(menu == 41)
menu = 20;

move = 0;
movez3 = 0;
moveA = 0;
moveB = 0;
moveC = 0;
moveC = 0;
moveD = 0;
poly = 0;
skelsize = 0;  
objscale = 3;
ANGSHIFT = 0;
tranz = 0;
oof = 0;
defZ = 0;
        
xui = 220;
yui = 130;
xok = 0;
run1 = 0;
run2 = 2;
jumpspeed = 0;
runs = 0;
resize = 0;
levelselect = 1;
repeat = false;
walk = 50;
health = 100;
health2 = 100; 
enemypos = 100;

break;  
}              
 

              
              
    
              
              
              
 if(i==0){             

     
if(i == 0) {               
case 0x1e:
    
    
    
    
    if(move == 360) {
    move = -90;
    
}
 
    


  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

if(menu == 20) {    
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0xAF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 

     gathrillo::models::Lv1 lvp1(0, -100, 0,0, 0, 1);        
     
        
gathrillo::models::CharAttack ridgey(10+xok, 65, 0,0, 0, 1, run1, run2);
        
     desktop5.Draw(&vga5);
   
        
    }
    
}
    
   
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      
    }
    
   

    
break;

}


              
         
      
        



if(i==0) {
case 0x31:          
/*
it1 = "A";
it2 = "X";
it3 = "T";
it4 = "D";
it5 = "E";
it6 = "F";
it7 = "G";
it8 = "H";      
    
flash = 1;
    */
   

break;  
}
              
              
              
              
              
if(i == 0) {               
case 0x32:
 

     


move = 90;

if(menu == 20) {    
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 



    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    
        
        
  
        
gathrillo::gui::Window polygon2(&desktop5, 9, svx, svy , 10, 10, 0x00 , 0xA8, 0x00, 4); 
desktop5.AddChild(&polygon2);
        
        
desktop5.Draw(&vga5);

 
    }
    
}
     if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      
        }
        

    }                
              
              
              
              
   
if(i==0) {
case 0x04:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

if(menu == 20) {
    
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        

    
gathrillo::models::BoxerDavieCrouchSprite(50,120,0,0,0x00,0x00,0x00);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  

desktop6.Draw(&vga6);
       
        
    }
    
}
    
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      
       
        


}
    
    
    
       

    
break;

}           
              
  
              
              
              
              
              

if(i==0) {
case 0x09:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

 if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        
        
if(walk > enemypos+33 && walk < enemypos + 60)
health2 -= 7;          
        
       
gathrillo::models::P2h(0, 0, health2,0, 0xAF, 0x00, 0x00);
        
        
gathrillo::models::P1h(0, 0, health,0, 0xAF, 0x00, 0x00);

    

gathrillo::models::Enemy(200, enemypos, 0x00, 0x00, 0x00, 0,25,100);


    
gathrillo::models::BoxerUpper(walk+1,97,0,0,0x00,0x00,0x00, 0);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  

 desktop6.Draw(&vga6);
           
    }
        
 }

  if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      

}
    
    
    
       

    
break;

}           
              
               
       
     

if(i==0) {
case 0x48:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
    if(menu == 20) {

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        
        
if(walk > enemypos+33 && walk < enemypos + 60)
health2 -= 7;          
        
       
gathrillo::models::P2h(0, 0, health2,0, 0xAF, 0x00, 0x00);
        
        
gathrillo::models::P1h(0, 0, health,0, 0xAF, 0x00, 0x00);

    

gathrillo::models::Enemy(200, enemypos, 0x00, 0x00, 0x00, 0,25,100);


    
gathrillo::models::BoxerJumpAnim(walk+1,105,0,0,0x00,0x00,0x00, 0);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  
desktop6.Draw(&vga6);

            
    }
}
        
        
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time
      
menu -= 1;        
    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
if(menu < 1)
menu = 3;
        
        
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      


}
   
       

    
break;

}           
             
     

if(i==0) {
case 0x0A:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
 if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        
        
if(walk > enemypos+33 && walk < enemypos + 60)
health2 -= 7;          
        
       
gathrillo::models::P2h(0, 0, health2,0, 0xAF, 0x00, 0x00);
        
        
gathrillo::models::P1h(0, 0, health,0, 0xAF, 0x00, 0x00);

    

gathrillo::models::Enemy(200, enemypos, 0x00, 0x00, 0x00, 0,25,100);


    
gathrillo::models::BoxerDavieBlockAnim(walk+1,97,0,0,0x00,0x00,0x00, 0);



//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  

            
        
desktop6.Draw(&vga6);
    
        
    }
     
 }
    
  if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      
}
    
    
    
       

    
break;

}           
              
  
              
              
              
              
              
              
              
              
              
              
   
if(i==0) {
case 0x01:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        

    
gathrillo::models::BoxerDavieSprite1(50,105,0,0,0x00,0x00,0x00);



//::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  
desktop6.Draw(&vga6);

            
    }
        
}
    
  if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
       
    


}
    
    
    
       

    
break;

}               
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
              
    
if(i==0) {
case 0x81:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
 if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        

    
gathrillo::models::BoxerDavieSprite2(50,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  


desktop6.Draw(&vga6);
        
        
            
    }
 
 }
  if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
          
        


}
    
    
    
       

    
break;

}              
              
              
              
              
              
              
              
              
   
if(i==0) {
case 0x05:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        

    
gathrillo::models::BoxerDavieSprite1(50,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  

desktop6.Draw(&vga6);

            
    }
}
   
  if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      


}
    
    
    
       

    
break;

}                  
 
              
              
              
if(i==0) {
case 0x4D:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 

        
        
walk += 15;  
        
gathrillo::models::P2h(0, 0, health2,0, 0xAF, 0x00, 0x00);
        
        
gathrillo::models::P1h(0, 0, health,0, 0xAF, 0x00, 0x00);

    
        
gathrillo::models::BoxerWalkAnim(walk,105,0,0,0x00,0x00,0x00);

gathrillo::models::Enemy(200, enemypos, 0x00, 0x00, 0x00, 0,25,100);


//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);


// gathrillo::models::Shoes2(48,105,0,0,0x00,0x00,0x00);

 //gathrillo::models::Shoes2(61,105,0,0,0x00,0x00,0x00);
        

desktop6.Draw(&vga6);
            
        
    }
    
}
    
    
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

   
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
 }
     
 
   
    
    
    
    
if(menu > 40) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

   
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    

menu += 1;  
  
if(menu > 54)
menu = 41;

        
gathrillo::models::Menu m(0, 0, menu);


//desktop6.Draw(&vga6);
       
        
    }
           
     


}
    
        
       

    
break;

}           
  
              
            
              
              
if(i==0) {
case 0x4B:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
walk -= 15;  
        
gathrillo::models::P2h(0, 0, health2,0, 0xAF, 0x00, 0x00);
        
        
gathrillo::models::P1h(0, 0, health,0, 0xAF, 0x00, 0x00);

gathrillo::models::Enemy(200, enemypos, 0x00, 0x00, 0x00, 0,25,100);

    
gathrillo::models::BoxerWalkAnim(walk,105,0,0,0x00,0x00,0x00);


//gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);


// gathrillo::models::Shoes2(48,105,0,0,0x00,0x00,0x00);

 //gathrillo::models::Shoes2(61,105,0,0,0x00,0x00,0x00);
        


desktop6.Draw(&vga6);
            
        
    }
}
    
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      
 }
 


    
   
 if(menu > 40) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

   
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    

menu -= 1;  
  
if(menu < 41)
menu = 54;

        
gathrillo::models::Menu m(0, 0, menu);


//desktop6.Draw(&vga6);
       
        
    }
           
     


} 
    
       

    
break;

}           
  
                   
              
              
              
              
              
  
if(i==0) {
case 0x06:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
if(menu == 20) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        

    
gathrillo::models::BoxerDavieSprite2(50,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  

        
desktop6.Draw(&vga6);
        
        
    }
        
}
     
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      
    
    


}
    
    
    
       

    
break;

}           
  

                    
              
            
      
  
if(i==0) {
case 0x07:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
          
        

    
gathrillo::models::BoxerDavieSprite3(50,105,0,0,0x00,0x00,0x00);



gathrillo::models::BoxerDavieShoes(50,105,0,0,0x00,0x00,0x00);
  

            
        
        
        
desktop6.Draw(&vga6);


}
    
    
    
       

    
break;

}          
                       

              
            
      
  
if(i==0) {
case 0x08:          

     if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

if(menu == 20) {    
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
        
if(walk > enemypos+30 && walk < enemypos + 60)
health2 -= 5;     


        
gathrillo::models::P2h(0, 0, health2,0, 0xAF, 0x00, 0x00);
        

gathrillo::models::P1h(0, 0, health,0, 0xAF, 0x00, 0x00);

gathrillo::models::Enemy(200, enemypos, 0x00, 0x00, 0x00, 0,25,100);
        
        
gathrillo::models::BoxerPunchAnim(walk,105,0,0,0x00,0x00,0x00);

  

            
        
        
        
desktop6.Draw(&vga6);


    }
    

}
       
  
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
 
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      

}
    
break;

}                
              
              
  /*            
              

if(i==0) {
case 0x39:          

    
    
    if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
  
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0xAF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

         if(levelselect == 1) {
     gathrillo::models::Lv1 lvp1(0, -100, 0,0, 0, 1);       
  }        
if(levelselect == 2) {
    
    
gathrillo::models::Lv2 lvp1(0, -100, 0,0, 0, 1);       
 
}
        
gathrillo::models::Enemy ene2(150, 80, 1,3, 0, 1, 10, 30-resize);


         if(levelselect == 1) {
     gathrillo::models::Lv1 lvp1(0, -100, 0,0, 0, 1);       
  }        
if(levelselect == 2) {
    
    
gathrillo::models::Lv2 lvp1(0, -100, 0,0, 0, 1);       
 
}
        
gathrillo::models::CharJump ridgeyjump(xok, 65, 0,0, 0, 1, run1, run2);
        
    
 gathrillo::models::Enemy ene1(150, 80, 1,3, 0, 1, 10, 30-resize);

   

        
        
desktop5.Draw(&vga5);

    }
    

    

    
break;

}    
    
     */
     
            
                 
if(i == 0) {               
case 0x4ffD:
    
    
    
    
    if(move == 360) {
    move = -90;
    
}
 
    

    xok += 10;
    
    runs += 1;
    
    if(runs >= 2){
        
        jumpspeed = 10;
        
        
    }
    
    if(run2 == 2){
        
        run2 = 0;
        
        run1 = 2;
        
    }
    
    
    if(run1 == 2){
        
        run1 = 0;
        
        run2 = 2;
        
    }
    
    

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0xAF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

        
        
        
        
 // Polygon reference common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b        
        
        
      
    
        
     // desktop5.AddChild(&poly41);    

      //(90, 9, 3 , 60, 50, 9, 4, 0x00 , 0xA8, 0x00); 
      


        
        
        
        
     //gathrillo::gui::Cube bruh(gathrillo::gui::Widget::Angle, 8, 50, 60, 100, 50, 0xFE, 0xFE, 0xFE);   
        
        
  //   gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
  
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
 
//gathrillo::gui::Dline a(move, 8, 50, 60, 1, 5, 0xFE, 0xFE, 0xFE); 
        
//gathrillo::models::FreezingFire ff(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
      
              
//gathrillo::gui::Polygon b1(90,0, 9, 3, 100, 20, 9, 4, 0xFE, 0xFE, 0xFE);
 
        
if(xok > 60 && xok < 75 && resize < 30) {
   
    
    xok = 10;
    
}   
 
        if(xok > 250){
            
            levelselect += 1;
            xok = 10;
        }
        
        
 if(levelselect == 1) {
     gathrillo::models::Lv1 lvp1(0, -100, 0,0, 0, 1);       
  }        
if(levelselect == 2) {
    
    
gathrillo::models::Lv2 lvp1(0, -100, 0,0, 0, 1);       
 
}
        
    gathrillo::models::Enemy ene1(150, 80, 0,0, 0, 1, 10, 30-resize);

     
        
gathrillo::models::Char ridgey(10+xok, 65, 0,0, 0, 1, run1, run2);
        
        
        

        
   
desktop5.Draw(&vga5);

    }
    
   

    
break;

}


              
         
              
              
if(i == 0) {              

case 0x4ffB:
 if(move == 360) {
    move = -90;
    
}
 

  move = 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    
xok -= 5;

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0xAF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

        
        
        
        
 // Polygon reference common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b        
        
        
      
    
        
     // desktop5.AddChild(&poly41);    

      //(90, 9, 3 , 60, 50, 9, 4, 0x00 , 0xA8, 0x00); 
      


        
        
        
        
     //gathrillo::gui::Cube bruh(gathrillo::gui::Widget::Angle, 8, 50, 60, 100, 50, 0xFE, 0xFE, 0xFE);   
        
        
  //     gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
  
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
 
        
        
              
//gathrillo::models::FreezingFire ff(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);

        
        
      gathrillo::models::Lv1 lvp1(0, -100, 0,0, 0, 1);     
        
    gathrillo::models::Enemy ene1(150, 80, 1,3, 0, 1, 10, 30-resize);
        
if(xok > 40) {
  resize = 30;  
}

        
gathrillo::models::CharAttack ridgey(10+xok, 65, 0,0, 0, 1, run1, run2);
        
   
desktop5.Draw(&vga5);

    }
    
   

    
break;

}

              
              
if(i == 0){
case 0x02:

ANGSHIFT = 0;
    
  break;  
}           
}           
              
 /*             
if(i == 0){
case 0x04:

ANGSHIFT = 180;
    
   break; 
}                 
              
  
  */            
              
              
              
      
      
   

    

             

              
              
 if(i == 0) {               
case 0x50:
 

 

     
     
     
id = 3;

if(ANGSHIFT == 90){
   
defZ = id;    
    
}
     
     
     
     
ANGSHIFT -= 10;   
tranz -= 1;
     
//if(tranz > 9){
    
  //  tranz = 0;
//}     

    
          
     
oof += 30;
move = 90;
skelsize = 10;
     
objscale += 1;
    
if(ANGSHIFT == 330) {
    
    ANGSHIFT = 250;
}
     
if(skelsize == -1){
    skelsize = 0;
    
}

 if(move == 360) {
    move = -90;
    
}
 
if(oof == 120) {
    
    oof = 0;
}
  //move += 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

if(menu == 20) {     
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0xA8,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0xFF , 0xFF, 0xFF, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0xA8,0x00); 



    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

repeat = true;        
        
 /*gathrillo::models::OBJReader obj(tranz, 0, ANGSHIFT, 100, 50, 0, 9, 0x00, 0x00, 0xA8, id, defZ);         
 gathrillo::models::OBJReader obj2(tranz, 0, ANGSHIFT, 100-10, 50, 0, 9, 0x00, 0x00, 0xA8, id, defZ);*/         
 //gathrillo::models::Char ridgey(0, 100, 0,0, 0, 1, run1, run2);
            
gathrillo::models::P2h(0, 0, health2,0, 0xAF, 0x00, 0x00);
        
        
gathrillo::models::P1h(0, 0, health,0, 0xAF, 0x00, 0x00);

    

gathrillo::models::Enemy(200, enemypos, 0x00, 0x00, 0x00, 0,25,100);


        
    gathrillo::models::BoxerCrouchAnim(walk,105,0,0,0x00,0x00,0x00, repeat);
    
        
        
        
   
desktop5.Draw(&vga5);


        

    }
    
}
    
 if(menu < 10) {
    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga6;
vga6.SetMode(320,200,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

menu += 1;
    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
//health = health; 
    
if(menu > 3)
menu = 1;
        
gathrillo::models::Menu m(0, 0, menu);


desktop6.Draw(&vga6);
       
        
    }
      
}

    
      
break;


}

    
    
    
    
    
    
//attack buttons 
              
if(i == 0) {               
case 0x19:
  
    
    move = 90;
    skelsize += 1;
    
  
    if(move == 360) {
    move = -90;
    
}
 

 // move += 90;  
  poly += 1;

   
if(move == 0){
      movez3 = moveA;
  }  
    
if(move == 90){
      movez3 = moveB;
  }  
    
if(move == 180){
      movez3 = moveC;
  }  
   
   
if(move == 270){
      movez3 = moveD;
  }  
    

    
 if(poly == 2 || 4 || 6 || 8 || 10 || 12 || 14 || 16 || 18 || 20 || 22 || 24 || 26 || 28 || 30 || 32 || 34 || 36 || 38 || 40 || 42 || 44 || 46 || 48 || 50){
    
VideoGraphicsArray vga6;
vga6.SetMode(160,120,8);
gathrillo::gui::Desktop desktop6(0,0, 0x00,0x00,0x00); 
gathrillo::gui::Camera cam2(move,0,0,movez3,0,0,0); 
    
    
gathrillo::gui::Window polygon2(&desktop6, 9, 0, 0 , 320, 200, 0x00 , 0x00, 0x00, 4); 
desktop6.AddChild(&polygon2);    

desktop6.Draw(&vga6);
    
poly += 1;
     
}    

    if(poly == 1 || 3 || 5 || 7 || 9 || 11 || 13 || 15 || 17 || 19 || 21 || 23 || 25 || 27 || 29 || 31 || 31 || 35 || 37 || 39 || 41 || 43 || 45 || 47 || 49) { 
        
    
VideoGraphicsArray vga5;
vga5.SetMode(320,200,8);
gathrillo::gui::Desktop desktop5(0,0, 0x00,0x00,0x00); 

//angle, x, y, z, rotx, roty, rotz  only one camera at a time

    
gathrillo::gui::Camera cam1(move,0,0,movez3,0,0,0); 
 
    

        
        
        
        
 // Polygon reference common::uint8_t ang, common::uint8_t size, common::uint8_t tri, common::int32_t x, common::int32_t y, common::int32_t w, common::int32_t h, common::uint8_t r, common::uint8_t g, common::uint8_t b        
        
        
      
    
        
     // desktop5.AddChild(&poly41);    

      //(90, 9, 3 , 60, 50, 9, 4, 0x00 , 0xA8, 0x00); 
      


        
        
        
        
        
        

it1 = "A";
it2 = "B";
it3 = "C";
it4 = "D";
it5 = "E";
it6 = "F";
it7 = "G";
it8 = "H";      
    
flash = 1;
    
        
        
        
        
        
        
        
        
        
     //gathrillo::gui::Cube bruh(gathrillo::gui::Widget::Angle, 8, 50, 60, 100, 50, 0xFE, 0xFE, 0xFE);   
        
        
       // gathrillo::models:: WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
  
        
        
       // gathrillo::models::Ground_3d_model WOW(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE);
 

    
      gathrillo::gui::Punch(90, 10,  50, 60, 10, 10, 0x00, 0x00, 0x00);

        
//    beep();    
     
        
        
//gathrillo::models::Gardenbed ok(9, 50, 50, 9, 4, 0xFE, 0xFE, 0xFE); 
        

   
desktop5.Draw(&vga5);

    }
    
   

    
break;

}

/*              
    
if(i==0) {
case 0x10:          

outl(0x4004, 0x3400);    

break;  
}
 
 */         
           
            
              
if(i==0) {
case 0x1f:          



break;  
}
          
           
    
              
              
      }
               
             
             
}
      return esp;
}
 


      

    
    
