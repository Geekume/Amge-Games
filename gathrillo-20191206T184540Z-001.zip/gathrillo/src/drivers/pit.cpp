#include <drivers/pit.h>

using namespace gathrillo;
using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;

void printf(char*);

PIT::PIT(hardwarecommunication::InterruptManager* manager)
: DataPort(0x40),
  CommandPort(0x43),
  InterruptHandler(manager, manager->HardwareInterruptOffset() + 0)
{
    timer_ticks = 0;

    uint64_t divisor = 1193180 / 1000;

    CommandPort.Write(0x36);
    DataPort.Write((uint8_t)divisor);
    DataPort.Write((uint8_t)(divisor >> 8));
}

uint32_t PIT::HandleInterrupt(uint32_t esp)
{
    timer_ticks++;
    return esp;
}
void PIT::Sleep(uint32_t ms)
{
   
    mp3 = false;
    
    //MS is the same as ticks because freq = 1000
    unsigned long eticks;
    
    
    eticks = timer_ticks + ms;
    while(timer_ticks < eticks){
   
if(mp3 == true){    
        
printf("-");

}
        
printf("bye you are stupid");
        timer_ticks++;
        loop = true;
        
    if(timer_ticks == eticks){
    printf("hi");
      
    if(mp3 == true){    
        
        printf("-");

    }    
        
        loop = true;
        break;
        
    }
        
    }
}


void PIT::PlaySound(common::uint32_t nFrequence)
{
    uint32_t Div;
 	uint8_t tmp;
 
        //Set the PIT to the desired frequency
 	Div = 1193180 / nFrequence;
 	outportb(0x43, 0xb6);
 	outportb(0x42, (uint8_t) (Div) );
 	outportb(0x42, (uint8_t) (Div >> 8));
 
        //And play the sound using the PC speaker
 	tmp = inportb(0x61);
  	if (tmp != (tmp | 3)) {
 		outportb(0x61, tmp | 3);
 	}
}
void PIT::NoSound()
{
    uint8_t tmp = inportb(0x61) & 0xFC;
 
 	outportb(0x61, tmp);
}
void PIT::Beep()
{
    Beep(1000); //1000 is default beep frequency
   
}

void PIT::end()
{

 Beep(60000050, 5000000000);
}


void PIT::Beep(common::uint32_t freq)
{
    Beep(freq, 10); //10 is default beep duration
}


void PIT::init()
{
    xs = 100;
}
void PIT::Beep(common::uint32_t freq, common::uint32_t duration)
{
    if(duration == 0)
        return;

    PlaySound(freq);
 	Sleep(duration);
 	NoSound();
}

void PIT::note(char* note, char* rest)
{
    int notes;
    int rests;
    
    Beep(notes, rests);
    
    //if(note == "c"){
        
      //  notes = 100;
        
//    }  
    if(note == "d"){
        
        notes = 200;
        
    }  
    if(note == "e"){
        
        notes = 300;
        
    }  
    if(note == "f#"){
        
        notes = 400;
        
    }  
    if(note == "g"){
        
        notes = 500;
        
    }  
    if(note == "a"){
        
        notes = 600;
        
    }  
    if(note == "b"){
        
        notes = 700;
        
    } 
    if(note == "c2"){
        
        notes = 800;
        
    }
  //  if (rest == "half") {
        
    //    rests = 100;
        
//    }
}


void PIT::music1()
{

    
    if( loop == true ){ 
    
    
        Beep(700, 2000);
        Sleep(10000);
        Beep(525, 2000);
        Sleep(10000);
        Beep(425, 2000);
        Sleep(10000);
        Beep(575, 2000);
        Sleep(10000);
        Beep(650, 2000);
        Sleep(10000);
        Beep(575, 2000);
        Sleep(2500);
        Beep(525, 2000);
        Sleep(5000);
        Beep(525, 2000);
        Sleep(7500);
        Beep(700, 2000);
        Sleep(7500);
        Beep(1025, 2000);
        Sleep(7500);
        Beep(1130, 2000);
        Sleep(7500);
        Beep(925, 2000);
        Sleep(5000);
        Beep(1025, 2000);
        Sleep(5000);
        Beep(875, 2000);
        Sleep(5000);
        Beep(700, 2000);
        Sleep(7500);
        Beep(800, 2000);
        Sleep(7500);
        Beep(650, 2000);
        Sleep(10000);
        Beep(700, 2000);
        Sleep(10000);
        Beep(525, 2000);
        Sleep(10000);
        Beep(425, 2000);
        Sleep(10000);
        Beep(575, 2000);
        Sleep(10000);
        Beep(650, 2000);
        Sleep(10000);
        Beep(575, 2000);
        Sleep(2500);
        Beep(525, 2000);
        Sleep(5000);
        Beep(525, 2000);
        Sleep(7500);
        Beep(700, 2000);
        Sleep(7500);
        Beep(1025, 2000);
        Sleep(7500);
        Beep(1130, 2000);
        Sleep(7500);
        Beep(925, 2000);
        Sleep(5000);
        Beep(1025, 2000);
        Sleep(5000);
        Beep(875, 2000);
        Sleep(5000);
        Beep(700, 2000);
        Sleep(7500);
        Beep(800, 2000);
        Sleep(7500);
        Beep(650, 2000);
        Sleep(1000);
        
        end();
    }
    
    if ( loop == false ) {
     Beep(650, 2000000);
    
    }
    
}
    
    
    void PIT::startup() {

    
      /*  
        Beep(200, 10000);
        Sleep(1000);
        
        */
        Beep(250, 10000);
        Sleep(1000);
        Beep(300, 2000);
        Sleep(1000);
        Beep(350, 2000);
        Sleep(1000);
       Beep(400, 2000);
        Sleep(1000);
        Beep(450, 2000);
        Sleep(1000);
       Beep(500, 2000);
        Sleep(1000);
        Beep(550, 2000);
        Sleep(1000);
       Beep(600, 2000);
        Sleep(1000);
        Beep(700, 20000);
        Sleep(1000);
       Beep(650, 50000);
        Sleep(1000);
       
       
    
    
}
 
void PIT::MainTheme() {
   
Beep(300, 7350); 

Sleep(150);    
    
    
Beep(300, 7350);
 
    
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
  
    
Beep(350, 7350);

Sleep(150);    
    
    
Beep(300, 7350);
    
    
Beep(300, 7350);
    
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
    
    
Beep(300, 7350);
    
Sleep(150);    
  
    
Beep(300, 7350);
   
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
  
    
Beep(350, 7350);  

Sleep(150);    
    
    
Beep(300, 7350);

Sleep(150);    
    
    
Beep(300, 7350);

Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
    
    
Beep(350, 7350);    
    
Sleep(150);    
        
Beep(300, 7350); 

Sleep(150);    
    
    
Beep(300, 7350);
 
    
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
  
    
Beep(350, 7350);

Sleep(150);    
    
    
Beep(300, 7350);
    
    
Beep(300, 7350);
    
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
    
    
Beep(300, 7350);
    
Sleep(150);    
  
    
Beep(300, 7350);
   
Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
  
    
Beep(350, 7350);  

Sleep(150);    
    
    
Beep(300, 7350);

Sleep(150);    
    
    
Beep(300, 7350);

Sleep(150);    
    
    
Beep(350, 7350);
    
Sleep(150);    
    
    
Beep(350, 7350);    
    
Sleep(15150);    
    
    
Beep(300, 30000);    
Beep(350, 10000);    
Beep(425, 30000);    
Sleep(25000);    
Beep(400, 30000);    
Beep(350, 15000);    
Beep(260, 30000);    

Sleep(25000);        
Beep(300, 30000);    
Beep(350, 10000);    
Beep(425, 30000);     
  

Sleep(25000);        
Beep(400, 30000);    
Beep(425, 5000);
Beep(400, 5000);    
Beep(350, 30000); 
Sleep(10000);        
Beep(300, 30000); 
Beep(300, 30000);    
Beep(350, 10000); 
Beep(425, 30000);     
Sleep(25000);        
Beep(500, 30000);    
Beep(425, 10000);    
Beep(450, 30000);     

Sleep(25000);         
Beep(450, 30000);    
Beep(425, 10000);    
Beep(375, 30000);     

Sleep(25000);             
Beep(260, 5000);    
Beep(300, 12500); 
Beep(260, 5000);    
Beep(300, 12500);  
Beep(260, 5000);    
Beep(300, 12500);  


Sleep(45000);         
  
Beep(300, 30000);    
Beep(350, 10000);    
Beep(425, 30000);    
Sleep(25000);    
Beep(400, 30000);    
Beep(350, 15000);    
Beep(260, 30000);    

Sleep(25000);        
Beep(300, 30000);    
Beep(350, 10000);    
Beep(425, 30000);     
  

Sleep(25000);        
Beep(400, 30000);    
Beep(425, 5000);
Beep(400, 5000);    
Beep(350, 30000); 
Sleep(10000);        
Beep(300, 30000); 
Beep(300, 30000);    
Beep(350, 10000); 
Beep(425, 30000);     
Sleep(25000);        
Beep(500, 30000);    
Beep(425, 10000);    
Beep(450, 30000);     

Sleep(25000);         
Beep(450, 30000);    
Beep(425, 10000);    
Beep(375, 30000);     

Sleep(25000);             
Beep(260, 5000);    
Beep(300, 12500); 
Beep(260, 5000);    
Beep(300, 12500);  
Beep(260, 5000);    
Beep(300, 12500);      
    
Sleep(35000);             
Beep(260, 5000);    
Beep(300, 12500); 
Beep(260, 5000);    
Beep(300, 12500);  
Beep(260, 5000);    
Beep(300, 12500);      
    
Sleep(35000);             
Beep(260, 5000);    
Beep(300, 12500); 
Beep(350, 5000);    
Beep(400, 12500);  
Beep(260, 5000);    
Beep(300, 12500);      
    

      
  /*	

	(killall VirtualBox && sleep 1) || true;
	VirtualBox --startvm "AMGE CONSOLE SDK" &
 */
    
    
}
 

void PIT::soundtest() {


    
    xs += 10;
    
    
      /*   
        Beep(200, 10000);
        Sleep(1000);
        
        */
        Beep(xs+10, 10000);
        Sleep(1000);
           Beep(xs+10, 10000);
        Sleep(1000);
           Beep(xs +30, 10000);
        Sleep(1000);
           Beep(xs +40, 10000);
        Sleep(1000);
           Beep(xs +50, 10000);
        Sleep(1000);
           Beep(xs +60, 10000);
        Sleep(1000);
           Beep(xs +70, 10000);
        Sleep(1000);
           Beep(xs +80, 10000);
        Sleep(1000);
           Beep(xs +90, 10000);
        Sleep(1000);
           Beep(xs +100, 10000);
        Sleep(1000);
    
        Beep(xs+110, 10000);
        Sleep(1000);
           Beep(xs+120, 10000);
        Sleep(1000);
           Beep(xs +130, 10000);
        Sleep(1000);
           Beep(xs +140, 10000);
        Sleep(1000);
           Beep(xs +150, 10000);
        Sleep(1000);
           Beep(xs +160, 10000);
        Sleep(1000);
           Beep(xs +170, 10000);
        Sleep(1000);
           Beep(xs +180, 10000);
        Sleep(1000);
           Beep(xs +190, 10000);
        Sleep(1000);
           Beep(xs +200, 10000);
        Sleep(1000);
          
          Beep(xs+210, 10000);
        Sleep(1000);
           Beep(xs+220, 10000);
        Sleep(1000);
           Beep(xs +230, 10000);
        Sleep(1000);
           Beep(xs +240, 10000);
        Sleep(1000);
           Beep(xs +250, 10000);
        Sleep(1000);
           Beep(xs +260, 10000);
        Sleep(1000);
           Beep(xs +270, 10000);
        Sleep(1000);
           Beep(xs +280, 10000);
        Sleep(1000);
           Beep(xs +290, 10000);
        Sleep(1000);
           Beep(xs +300, 10000);
        Sleep(1000);
    
        Beep(xs+310, 10000);
        Sleep(1000);
           Beep(xs+320, 10000);
        Sleep(1000);
           Beep(xs +330, 10000);
        Sleep(1000);
           Beep(xs +340, 10000);
        Sleep(1000);
           Beep(xs +350, 10000);
        Sleep(1000);
           Beep(xs +360, 10000);
        Sleep(1000);
           Beep(xs +370, 10000);
        Sleep(1000);
           Beep(xs +380, 10000);
        Sleep(1000);
           Beep(xs +390, 10000);
        Sleep(1000);
           Beep(xs +400, 10000);
        Sleep(1000);
    
    
    
      Beep(xs+410, 10000);
        Sleep(1000);
           Beep(xs+420, 10000);
        Sleep(1000);
           Beep(xs +430, 10000);
        Sleep(1000);
           Beep(xs +440, 10000);
        Sleep(1000);
           Beep(xs +450, 10000);
        Sleep(1000);
           Beep(xs +460, 10000);
        Sleep(1000);
           Beep(xs +470, 10000);
        Sleep(1000);
           Beep(xs +480, 10000);
        Sleep(1000);
           Beep(xs +490, 10000);
        Sleep(1000);
           Beep(xs +500, 10000);
        Sleep(1000);
    
        Beep(xs+510, 10000);
        Sleep(1000);
           Beep(xs+520, 10000);
        Sleep(1000);
           Beep(xs +530, 10000);
        Sleep(1000);
           Beep(xs +540, 10000);
        Sleep(1000);
           Beep(xs +550, 10000);
        Sleep(1000);
           Beep(xs +560, 10000);
        Sleep(1000);
           Beep(xs +570, 10000);
        Sleep(1000);
           Beep(xs +580, 10000);
        Sleep(1000);
           Beep(xs +590, 10000);
        Sleep(1000);
           Beep(xs +600, 10000);
        Sleep(1000);
      
    Beep(xs+610, 10000);
        Sleep(1000);
           Beep(xs+620, 10000);
        Sleep(1000);
           Beep(xs +630, 10000);
        Sleep(1000);
           Beep(xs +640, 10000);
        Sleep(1000);
           Beep(xs +650, 10000);
        Sleep(1000);
           Beep(xs +660, 10000);
        Sleep(1000);
           Beep(xs +670, 10000);
        Sleep(1000);
           Beep(xs +680, 10000);
        Sleep(1000);
           Beep(xs +690, 10000);
        Sleep(1000);
           Beep(xs +700, 10000);
        Sleep(1000);
    
        Beep(xs+510, 10000);
        Sleep(1000);
           Beep(xs+720, 10000);
        Sleep(1000);
           Beep(xs +730, 10000);
        Sleep(1000);
           Beep(xs +740, 10000);
        Sleep(1000);
           Beep(xs +750, 10000);
        Sleep(1000);
           Beep(xs +760, 10000);
        Sleep(1000);
           Beep(xs +770, 10000);
        Sleep(1000);
           Beep(xs +780, 10000);
        Sleep(1000);
           Beep(xs +790, 10000);
        Sleep(1000);
           Beep(xs +800, 10000);
        Sleep(1000);
          
    
    
     Beep(xs+610, 10000);
        Sleep(1000);
           Beep(xs+820, 10000);
        Sleep(1000);
           Beep(xs +830, 10000);
        Sleep(1000);
           Beep(xs +840, 10000);
        Sleep(1000);
           Beep(xs +850, 10000);
        Sleep(1000);
           Beep(xs +860, 10000);
        Sleep(1000);
           Beep(xs +870, 10000);
        Sleep(1000);
           Beep(xs +880, 10000);
        Sleep(1000);
           Beep(xs +890, 10000);
        Sleep(1000);
           Beep(xs +900, 10000);
        Sleep(1000);
    
        Beep(xs+910, 10000);
        Sleep(1000);
           Beep(xs+920, 10000);
        Sleep(1000);
           Beep(xs +930, 10000);
        Sleep(1000);
           Beep(xs +940, 10000);
        Sleep(1000);
           Beep(xs +950, 10000);
        Sleep(1000);
           Beep(xs +960, 10000);
        Sleep(1000);
           Beep(xs +970, 10000);
        Sleep(1000);
           Beep(xs +980, 10000);
        Sleep(1000);
           Beep(xs +990, 10000);
        Sleep(1000);
           Beep(xs +1000, 10000);
        Sleep(1000);
          
        
     Beep(xs+990, 10000);
        Sleep(1000);
           Beep(xs+980, 10000);
        Sleep(1000);
           Beep(xs +970, 10000);
        Sleep(1000);
           Beep(xs +960, 10000);
        Sleep(1000);
           Beep(xs +950, 10000);
        Sleep(1000);
           Beep(xs +940, 10000);
        Sleep(1000);
           Beep(xs +930, 10000);
        Sleep(1000);
           Beep(xs +920, 10000);
        Sleep(1000);
           Beep(xs +910, 10000);
        Sleep(1000);
           Beep(xs +800, 10000);
        Sleep(1000);
          
          Beep(xs+890, 10000);
        Sleep(1000);
           Beep(xs+880, 10000);
        Sleep(1000);
           Beep(xs +870, 10000);
        Sleep(1000);
           Beep(xs +860, 10000);
        Sleep(1000);
           Beep(xs +850, 10000);
        Sleep(1000);
           Beep(xs +840, 10000);
        Sleep(1000);
           Beep(xs +830, 10000);
        Sleep(1000);
           Beep(xs +820, 10000);
        Sleep(1000);
           Beep(xs +810, 10000);
        Sleep(1000);
           Beep(xs +800, 10000);
        Sleep(1000);
          
    
      Beep(xs+790, 10000);
        Sleep(1000);
           Beep(xs+780, 10000);
        Sleep(1000);
           Beep(xs +770, 10000);
        Sleep(1000);
           Beep(xs +760, 10000);
        Sleep(1000);
           Beep(xs +750, 10000);
        Sleep(1000);
           Beep(xs +740, 10000);
        Sleep(1000);
           Beep(xs +730, 10000);
        Sleep(1000);
           Beep(xs +720, 10000);
        Sleep(1000);
           Beep(xs +710, 10000);
        Sleep(1000);
           Beep(xs +700, 10000);
        Sleep(1000);
          
          Beep(xs+690, 10000);
        Sleep(1000);
           Beep(xs+680, 10000);
        Sleep(1000);
           Beep(xs +670, 10000);
        Sleep(1000);
           Beep(xs +660, 10000);
        Sleep(1000);
           Beep(xs +650, 10000);
        Sleep(1000);
           Beep(xs +640, 10000);
        Sleep(1000);
           Beep(xs +630, 10000);
        Sleep(1000);
           Beep(xs +620, 10000);
        Sleep(1000);
           Beep(xs +610, 10000);
        Sleep(1000);
           Beep(xs +600, 10000);
        Sleep(1000);
    
    
    
       Beep(xs+590, 10000);
        Sleep(1000);
           Beep(xs+580, 10000);
        Sleep(1000);
           Beep(xs +570, 10000);
        Sleep(1000);
           Beep(xs +560, 10000);
        Sleep(1000);
           Beep(xs +550, 10000);
        Sleep(1000);
           Beep(xs +540, 10000);
        Sleep(1000);
           Beep(xs +530, 10000);
        Sleep(1000);
           Beep(xs +520, 10000);
        Sleep(1000);
           Beep(xs +510, 10000);
        Sleep(1000);
           Beep(xs +500, 10000);
        Sleep(1000);
          
          Beep(xs+490, 10000);
        Sleep(1000);
           Beep(xs+480, 10000);
        Sleep(1000);
           Beep(xs +470, 10000);
        Sleep(1000);
           Beep(xs +460, 10000);
        Sleep(1000);
           Beep(xs +450, 10000);
        Sleep(1000);
           Beep(xs +440, 10000);
        Sleep(1000);
           Beep(xs +430, 10000);
        Sleep(1000);
           Beep(xs +420, 10000);
        Sleep(1000);
           Beep(xs +410, 10000);
        Sleep(1000);
           Beep(xs +400, 10000);
        Sleep(1000);
      
        Beep(xs+390, 10000);
        Sleep(1000);
           Beep(xs+380, 10000);
        Sleep(1000);
           Beep(xs +370, 10000);
        Sleep(1000);
           Beep(xs +360, 10000);
        Sleep(1000);
           Beep(xs +350, 10000);
        Sleep(1000);
           Beep(xs +340, 10000);
        Sleep(1000);
           Beep(xs +330, 10000);
        Sleep(1000);
           Beep(xs +320, 10000);
        Sleep(1000);
           Beep(xs +310, 10000);
        Sleep(1000);
           Beep(xs +300, 10000);
        Sleep(1000);
          
          Beep(xs+290, 10000);
        Sleep(1000);
           Beep(xs+280, 10000);
        Sleep(1000);
           Beep(xs +270, 10000);
        Sleep(1000);
           Beep(xs +260, 10000);
        Sleep(1000);
           Beep(xs +250, 10000);
        Sleep(1000);
           Beep(xs +240, 10000);
        Sleep(1000);
           Beep(xs +230, 10000);
        Sleep(1000);
           Beep(xs +220, 10000);
        Sleep(1000);
           Beep(xs +210, 10000);
        Sleep(1000);
           Beep(xs +200, 10000);
        Sleep(1000);
    
        Beep(xs+190, 10000);
        Sleep(1000);
           Beep(xs+180, 10000);
        Sleep(1000);
           Beep(xs +170, 10000);
        Sleep(1000);
           Beep(xs +160, 10000);
        Sleep(1000);
           Beep(xs +150, 10000);
        Sleep(1000);
           Beep(xs +140, 10000);
        Sleep(1000);
           Beep(xs +130, 10000);
        Sleep(1000);
           Beep(xs +120, 10000);
        Sleep(1000);
           Beep(xs +110, 10000);
        Sleep(1000);
           Beep(xs +100, 10000);
        Sleep(1000);
          
          Beep(xs+90, 10000);
        Sleep(1000);
           Beep(xs+80, 10000);
        Sleep(1000);
           Beep(xs +70, 10000);
        Sleep(1000);
           Beep(xs +60, 10000);
        Sleep(1000);
           Beep(xs +50, 10000);
        Sleep(1000);
           Beep(xs +40, 10000);
        Sleep(1000);
           Beep(xs +30, 10000);
        Sleep(1000);
           Beep(xs +20, 10000);
        Sleep(1000);
           Beep(xs +10, 10000);
        Sleep(1000);
           Beep(xs, 10000);
        Sleep(1000);
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}

    

     

