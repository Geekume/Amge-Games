#include <common/types.h>
#include <gdt.h>
#include <hardwarecommunication/interrupts.h>
#include <hardwarecommunication/pci.h>
#include <drivers/driver.h>
#include <drivers/game.h>
#include <drivers/mouse.h>
#include <drivers/vga.h>
#include <drivers/ata.h>
#include <drivers/io.h>
#include <drivers/pit.h>
#include <gui/desktop.h>
#include <gui/window.h>
#include <memorymanagement.h>
#include <drivers/math.h>
#include <models/models.h>



using namespace gathrillo;
using namespace gathrillo::common;
using namespace gathrillo::drivers;
using namespace gathrillo::hardwarecommunication;
using namespace gathrillo::models;

using namespace gathrillo::gui;

bool refresh = true;
int d = 1;


void printf(char* str) {
    static uint16_t* VideoMemory = (uint16_t*)0xb8000;
    
    static uint16_t x=0,y=0;
    

    
    
    
  for(int i = 0; str[i] != '\0'; ++i)
    {
        switch(str[i])
        {
            case '\n':
                x = 0;
                y++;
                break;
            default:
                VideoMemory[80*y+x] = (VideoMemory[80*y+x] & 0xFF00) | str[i];
                x++;
                break;
        }

        if(x >= 80)
        {
            x = 0;
            y++;
            
            
        }
    
    
        if(y >= 25)
        {
            for(y = 0; y < 25; y++)
                for(x = 0; x < 80; x++)
                    VideoMemory[80*y+x] = (VideoMemory[80*y+x] & 0xFF00) | ' ';
            x = 0;
            y = 0;
        }
    }
}

void printfHex(uint8_t key)
{
     char* foo = "00";
     char* hex = "0123456789ABCDEF";
     foo[0] = hex[(key >> 4) & 0x0F];
     foo[1] = hex[key & 0x0F];
     
     printf(foo);
     
}


void printfHex16(uint16_t key)
{
    printfHex((key >> 8) & 0xFF);
    printfHex( key & 0xFF);
}
void printfHex32(uint32_t key)
{
    printfHex((key >> 24) & 0xFF);
    printfHex((key >> 16) & 0xFF);
    printfHex((key >> 8) & 0xFF);
    printfHex( key & 0xFF);
}

void printfHex64(uint32_t key)
{
    printfHex((key >> 48) & 0xFF);
    printfHex((key >> 40) & 0xFF);
    printfHex((key >> 32) & 0xFF);
    printfHex((key >> 24) & 0xFF);
    printfHex((key >> 16) & 0xFF);
    printfHex((key >> 8) & 0xFF);
    printfHex( key & 0xFF);
}



class PrintfGameEventHandler : public GameEventHandler
{
    void OnGameKeyDown(char c) 
    {
        char* foo = " ";
        foo[0] = c;
        printf(foo);
    }
};

class MouseToConsole : public MouseEventHandler
{
    int8_t x, y;
public:
  
  MouseToConsole() 
  {
      static uint32_t* VideoMemory = (uint32_t*)0xb8000;
       x = 40;
       y = 12;
       
       VideoMemory[80*12+40] = (((VideoMemory[80*12+40]) & 0xF000) >> 4)
                             | (((VideoMemory[80*12+40]) & 0x0F00) << 4)
                             | ((VideoMemory[80*12+40]) & 0x00FF);
  }
    
    
    
  void OnMouseMove(int xoffset, int yoffset) 
  {
          static uint16_t* VideoMemory = (uint16_t*)0xb8000;
        /*
          VideoMemory[80*y+x] = ((VideoMemory[80*y+x]) & 0xF000) >> 0
                              | ((VideoMemory[80*y+x]) & 0x0F00) >> 1
                              | ((VideoMemory[80*y+x]) & 0x00FF) << 2;
                               */
                              
        VideoMemory[80*y+x] = (((VideoMemory[80*y+x]) & 0xF000) >> 4)
                               | (((VideoMemory[80*y+x]) & 0x0F00) << 4)
                               | ((VideoMemory[80*y+x]) & 0x00FF);                      
                               
                              
                              
          x += xoffset;
          
          
          if(x < 0) x = 0;
          if(x >= 80) x = 79;
          
          
          y += yoffset;
          if(y < 0) y = 0;
          if(y >= 25) y = 24;
          
          
          
           VideoMemory[80*y+x] = (((VideoMemory[80*y+x]) & 0xF000) >> 4)
                              | (((VideoMemory[80*y+x]) & 0x0F00) << 4)
                              | ((VideoMemory[80*y+x]) & 0x00FF);
                              
//            VideoMemory[80*y+x] = ((VideoMemory[80*y+x]) & 0xF000) >> 0
//                               | ((VideoMemory[80*y+x]) & 0x0F00) >> 1
//                               | ((VideoMemory[80*y+x]) & 0x00FF) << 2;
                              
  }
};

//int a = 1;
//char b = (char)(a + '0');
/*void taskA()
{
    while(true) {
    GlobalDescriptorTable gdt;
    TaskManager taskManager;
    InterruptManager interrupts(0x20, &gdt, &taskManager);
    PIT pit(&interrupts);
    pit.music1();
    }
}


void taskB()
{
    //while(true)
        //printf("B");
}*/




        
    

typedef void (*constructor)();
extern "C" constructor start_ctors;
extern "C" constructor end_ctors;
extern "C" void callConstructors()
{
    for(constructor* i = &start_ctors; i != &end_ctors; i++)
        (*i)();
}

    


extern "C" void kernelMain (const void* multiboot_structure, uint32_t, char* str /* multiboot_magic*/ ) {

    

    
    
  
    
    
    
    //printf("GAMES ");
    //printf("Apps ");
    //printf("Settings ");
    //printf("Store\n ");
    
    GlobalDescriptorTable gdt;
    
    
    
    uint32_t* memupper = (uint32_t*)(((size_t)multiboot_structure) + 8);
    size_t heap = 10*1024*1024;
    MemoryManager memoryManager(heap, (*memupper)*1024 - heap - 10*1024);

    printf("heap: 0x");
    printfHex((heap >> 24) & 0xFF);
    printfHex((heap >> 16) & 0xFF);
    printfHex((heap >> 8 ) & 0xFF);
    printfHex((heap      ) & 0xFF);

    void* allocated = memoryManager.malloc(1024);
    printf("\nallocated: 0x");
    printfHex(((size_t)allocated >> 24) & 0xFF);
    printfHex(((size_t)allocated >> 16) & 0xFF);
    printfHex(((size_t)allocated >> 8 ) & 0xFF);
    printfHex(((size_t)allocated      ) & 0xFF);
    printf("\n");
    printf("\n");
    printf("\n");

    
    
    TaskManager taskManager;
    
        
    //Task task1(&gdt, taskA);
    //Task task2(&gdt, taskB);
   // taskManager.AddTask(&task1);
    //taskManager.AddTask(&task2);
    
    
    InterruptManager interrupts(0x20, &gdt, &taskManager);
     
    
    
   PIT pit(&interrupts);
  
    
  

        

    Desktop desktop(320,200, 0x00,0x00,0x00);
    
    DriverManager drvManager;
     
  
        //PrintfKeyboardEventHandler kbhandler;
        //KeyboardDriver keyboard(&interrupts, &kbhandler);
        GameDriver Game(&interrupts, &desktop);
        drvManager.AddDriver(&Game);
        
  //printf("Initializing Hardware 66%\n \n"); 
    
    
        //MouseToConsole mousehandler;
        //MouseDriver mouse(&interrupts, &mousehandler);
        //MouseDriver mouse(&interrupts, &desktop);
        //drvManager.AddDriver(&mouse);
    
     PeripheralComponentInterconnectController PCIController;
     PCIController.SelectDrivers(&drvManager, &interrupts);
    
     drvManager.ActivateAll();
    
     interrupts.Activate();

/*

        printf("\nS-ATA primary master: ");
        AdvancedTechnologyAttachment ata0m(true, 0x1F0);
        ata0m.Identify();

        printf("\nS-ATA primary slave: ");
        AdvancedTechnologyAttachment ata0s(false, 0x1F0);
        ata0s.Identify();
        printf("\n");
        printf("\n");
        printf("\n");
        //ata0s.Write28(0, (uint8_t*) , 13);
        //ata0s.Flush();
        printf("\n");
        printf("\n");
        printf("\n");
        ata0s.Read28(0);

        printf("\nS-ATA secondary master: ");
        AdvancedTechnologyAttachment ata1m(true, 0x170);
        ata1m.Identify();

        printf("\nS-ATA secondary slave: ");
        AdvancedTechnologyAttachment ata1s(false, 0x170);
        ata1s.Identify();

    */

    //Game.sfx(false, 1);

   // pit.startup();
    
    
    
   
    
    
    pit.startup();
    
    
    pit.Beep(500000, 50000000000);
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
    pit.MainTheme();

    pit.Sleep(45000); 
    
    
   // pit.music1();
   
    
    //pit.init();
    
    
    
    
   ///  pit.music1();

    /*
    
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest(); 
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    pit.soundtest();
    */
    //pit.note("d", "half");
    
    int n1;
    int n2;
    
    n1 = 1;
    n2 = 1;
    
    
double y;     

y = (int)ok::Math::sin(36);
        
printfHex16(y);


}
